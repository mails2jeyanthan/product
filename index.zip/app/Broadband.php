<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Broadband extends Model
{
    protected $fillable = [
        'prov_name','product', 'price'
    ];
    protected $primaryKey='id';
}
