<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Energy extends Model
{
    protected $fillable = [
        'prov_name','product', 'product_variation', 'price'
    ];
    protected $primaryKey='id';
}
