<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Energy;
use Response;

class EnergyController extends Controller
{
    public $successStatus = 200;

    public function get(Request $request)
    {
    	$data = $request->data;

                 $drivers = Energy::where('prov_name', 'Like', '%'.$data.'%')->orwhere('product_variation', 'Like', '%'.$data.'%')->orwhere('product', 'Like', '%'.$data.'%')->get();
                 if (count($drivers) >= 1) {
                 	$success['Energy'] = $drivers;
                 	 return response()->json(['success' => $success], $this->successStatus);
                 }
                 else{
                 	$message = "Sorry. Energy Provider Not Found.";
                 	return Response::json([
                     'data' => $message
                     ]);

                 }

        
    }
    public function update(Request $request)
    {
    	$id = $request->id;
    	$price = $request->price;
    	$Pr = Energy::where('id', '=', $id)->get();
    	if (count($Pr) >= 1) {
    		$passport= \App\Energy::findorfail($id);
        $passport->price=$price;
        
        $passport->save();
        $success['Energy'] = Energy::where('id', '=', $id)->get();
        return response()->json(['success' => $success], $this->successStatus);
    	}
    	else{
    		$message = "Sorry. Given id Not Found.";
                 	return Response::json([
                     'data' => $message
                     ]);

    	}

    	

    }
}
