<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\UploadRequest;
use Illuminate\Support\Facades\DB; 
use Auth;
use Storage;
use store;
use App\Category;
use App\Post;
use App\Emotion;
use App\Title;
use App\Blog;
use App\Breathing;
use App\Food;
use App\Master;
use App\Meditation;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Posts = Post::get();
        $Emotions = Emotion::get();
        $Titles = Title::get();
        $Blogs = Blog::get();
        $Breathings = Breathing::get();
        $Foods = Food::get();
        $Masters = Master::get();
        $Meditations = Meditation::get();
        return view('home', compact('Posts', 'Emotions', 'Titles', 'Blogs', 'Breathings', 'Foods', 'Masters', 'Meditations'));
    }

    public function manage()
    {
        $Posts = Post::get();
        $Emotions = Emotion::get();
        $Titles = Title::get();
        $Blogs = Blog::get();
        $Breathings = Breathing::get();
        $Foods = Food::get();
        $Masters = Master::get();
        $Meditations = Meditation::get();
        return view('/manage-post', compact('Posts', 'Emotions', 'Titles', 'Blogs', 'Breathings', 'Foods', 'Masters', 'Meditations'));
    }

    public function addcat()
    {
        return view('/add-category');
    }
    public function addcategory(Request $request)
    {
        $Categories = Category::create([
            'category'=> $request['category'],
            'seodescription'=> $request['seodescription'],
            'h1tag'=> $request['h1tag'],
            'seotitle' => $request['seotitle'],                 
            
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
        
    }

    /*------------------------------------------Model 1--------------------------------------------*/
    public function addpot()
    {
        $Category = Category::get();
        return view('/add-post', compact('Category'));
    }
    public function destroy($pst_id)
    {
        
        $Posts = Post::findOrFail($pst_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function editpot($pst_id)
    {
        
        $Posts = Post::findOrFail($pst_id);
        return view('/edit-post-1', compact('Posts'));

    }
    public function addpost(Request $request)
    {
        if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
           }
           else{
            $image5 = "";
          }
        $Posts = Post::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
        
    }
    public function updatepost(Request $request, $pst_id)
    {
        
        $passport= \App\Post::find($pst_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    public function updateimgpost(Request $request, $pst_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Post::find($pst_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Post::find($pst_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Post::find($pst_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Post::find($pst_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
            $passport= \App\Post::find($pst_id);
            $passport->image5=$image5;
            $passport->save();
           }
           else{
           
          }
        
        
        
        return redirect()->back();
    }
    public function publishpost(Request $request, $pst_id)
    {
        
        $passport= \App\Post::find($pst_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    /*-----------------------------------------Model 2-------------------------------------------------*/
    public function addpot2()
    {
        $Category = Category::get();
        return view('/add-post-2', compact('Category'));
    }
    public function editpot2($emt_id)
    {
        
        $Emotions = Emotion::findOrFail($emt_id);
        return view('/edit-post-2', compact('Emotions'));

    }
    public function updatepost2(Request $request, $emt_id)
    {
        
        $passport= \App\Emotion::find($emt_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
        $passport->editor4=$request->get('editor4');
        $passport->editor5=$request->get('editor5');
        $passport->editor6=$request->get('editor6');
        $passport->editor7=$request->get('editor7');
        $passport->editor8=$request->get('editor8');
        $passport->editor9=$request->get('editor9');
        $passport->editor10=$request->get('editor10');
        
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
     public function destroy2($emt_id)
    {
        
        $Posts = Emotion::findOrFail($emt_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function addpost2(Request $request)
    {
        if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
           }
           else{
            $image5 = "";
          }
          if($request->image6 != "") 
           {
            $image = $request->image6;
            $image6 = $image->store('upload');
           }
           else{
            $image6 = "";
          }
          if($request->image7 != "") 
           {
            $image = $request->image7;
            $image7 = $image->store('upload');
           }
           else{
            $image7 = "";
          }
        $Emotions = Emotion::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            'editor4'=> $request['editor4'],
            'editor5'=> $request['editor5'],
            'editor6'=> $request['editor6'],
            'editor7'=> $request['editor7'],
            'editor8'=> $request['editor8'],
            'editor9'=> $request['editor9'],
            'editor10'=> $request['editor10'],
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5,
            'image6' => $image6,
            'image7' => $image7,
            
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
        
    }
    public function updateimgpost2(Request $request, $emt_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Emotion::find($emt_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Emotion::find($emt_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Emotion::find($emt_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Emotion::find($emt_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
            $passport= \App\Emotion::find($emt_id);
            $passport->image5=$image5;
            $passport->save();
           }
           else{
           
          }
          if($request->image6 != "") 
           {
            $image = $request->image6;
            $image6 = $image->store('upload');
            $passport= \App\Emotion::find($emt_id);
            $passport->image6=$image6;
            $passport->save();
           }
           else{
           
          }
          if($request->image7 != "") 
           {
            $image = $request->image7;
            $image7 = $image->store('upload');
            $passport= \App\Emotion::find($emt_id);
            $passport->image7=$image7;
            $passport->save();
           }
           else{
           
          }
        
        
        
        return redirect()->back();
    }
    public function publishpost2(Request $request, $emt_id)
    {
        
        $passport= \App\Emotion::find($emt_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    /*-----------------------------------------Model 3-------------------------------------------------*/
    public function addpot3()
    {
        $Category = Category::get();
        return view('/add-post-3', compact('Category'));
    }
    public function editpot3($tt_id)
    {
        
        $Titles = Title::findOrFail($tt_id);
        return view('/edit-post-3', compact('Titles'));

    }
    public function updatepost3(Request $request, $tt_id)
    {
        
        $passport= \App\Title::find($tt_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
         $passport->editor4=$request->get('editor4');
       
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    public function destroy3($tt_id)
    {
        
        $Posts = Title::findOrFail($tt_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function addpost3(Request $request)
    {
        if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
           }
           else{
            $image5 = "";
          }
          
        $Titles = Title::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            'editor4'=> $request['editor4'],
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5,
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
        
    }
    public function updateimgpost3(Request $request, $tt_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Title::find($tt_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Title::find($tt_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Title::find($tt_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Title::find($tt_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
            $passport= \App\Title::find($tt_id);
            $passport->image5=$image5;
            $passport->save();
           }
           else{
           
          }
       return redirect()->back();
    }
    public function publishpost3(Request $request, $tt_id)
    {
        
        $passport= \App\Title::find($tt_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    /*------------------------------------------Model 4-----------------------------------------------*/
    public function addpot4()
    {
        $Category = Category::get();
        return view('/add-post-4', compact('Category'));
    }
    public function editpot4($bg_id)
    {
        
        $Blogs = Blog::findOrFail($bg_id);
        return view('/edit-post-4', compact('Blogs'));

    }
    public function updatepost4(Request $request, $bg_id)
    {
        
        $passport= \App\Blog::find($bg_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
         $passport->editor4=$request->get('editor4');
        $passport->editor5=$request->get('editor5');
        
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    public function destroy4($bg_id)
    {
        
        $Posts = Blog::findOrFail($bg_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function addpost4(Request $request)
    {
        if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
           }
           else{
            $image5 = "";
          }
          
        $Blogs = Blog::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            'editor4'=> $request['editor4'],
            'editor5'=> $request['editor5'],
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5,
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
        
    }
    public function updateimgpost4(Request $request, $bg_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Blog::find($bg_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Blog::find($bg_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Blog::find($bg_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Blog::find($bg_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
            $passport= \App\Blog::find($bg_id);
            $passport->image5=$image5;
            $passport->save();
           }
           else{
           
          }
       return redirect()->back();
    }
    public function publishpost4(Request $request, $bg_id)
    {
        
        $passport= \App\Blog::find($bg_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    /*------------------------------------------Model 5-----------------------------------------------*/
    public function addpot5()
    {
        $Category = Category::get();
        return view('/add-post-5', compact('Category'));
    }
    public function editpot5($br_id)
    {
        
        $Breathings = Breathing::findOrFail($br_id);
        return view('/edit-post-5', compact('Breathings'));

    }
    public function updatepost5(Request $request, $br_id)
    {
        $passport= \App\Breathing::find($br_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
        $passport->editor4=$request->get('editor4');
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    public function destroy5($br_id)
    {
        
        $Posts = Breathing::findOrFail($br_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function addpost5(Request $request)
    {
        if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
           }
           else{
            $image5 = "";
          }
          
        $Breathings = Breathing::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            'editor4'=> $request['editor4'],
            'editor5'=> $request['editor5'],
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5,
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
    }
    public function updateimgpost5(Request $request, $br_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Breathing::find($br_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Breathing::find($br_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Breathing::find($br_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Breathing::find($br_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
            $passport= \App\Breathing::find($br_id);
            $passport->image5=$image5;
            $passport->save();
           }
           else{
           
          }
      return redirect()->back();
    }
    public function publishpost5(Request $request, $br_id)
    {
        
        $passport= \App\Breathing::find($br_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    /*------------------------------------------Model 6-----------------------------------------------*/
    public function addpot6()
    {
        $Category = Category::get();
        return view('/add-post-6', compact('Category'));
    }
    public function editpot6($fd_id)
    {
        
        $Foods = Food::findOrFail($fd_id);
        return view('/edit-post-6', compact('Foods'));

    }
    public function updatepost6(Request $request, $fd_id)
    {
        
        $passport= \App\Food::find($fd_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
         $passport->editor4=$request->get('editor4');
        $passport->editor5=$request->get('editor5');
        $passport->editor6=$request->get('editor6');
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
     public function destroy6($fd_id)
    {
        
        $Posts = Food::findOrFail($fd_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function addpost6(Request $request)
    {
        if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
           }
           else{
            $image5 = "";
          }
          
        $Foods = Food::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            'editor4'=> $request['editor4'],
            'editor5'=> $request['editor5'],
            'editor6'=> $request['editor6'],
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5,
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
        
    }
    public function updateimgpost6(Request $request, $fd_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Food::find($fd_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Food::find($fd_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Food::find($fd_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Food::find($fd_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
            $passport= \App\Food::find($fd_id);
            $passport->image5=$image5;
            $passport->save();
           }
           else{
           
          }
        
        
        
        return redirect()->back();
    }
    public function publishpost6(Request $request, $fd_id)
    {
        
        $passport= \App\Food::find($fd_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    /*------------------------------------------Model 7-----------------------------------------------*/
    public function addpot7()
    {
        $Category = Category::get();
        return view('/add-post-7', compact('Category'));
    }
    public function editpot7($ms_id)
    {
        
        $Masters = Master::findOrFail($ms_id);
        return view('/edit-post-7', compact('Masters'));

    }
    public function updatepost7(Request $request, $ms_id)
    {
        
        $passport= \App\Master::find($ms_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    public function destroy7($ms_id)
    {
        
        $Posts = Master::findOrFail($ms_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function addpost7(Request $request)
    {
        if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
           }
           else{
            $image5 = "";
          }
          if($request->image6 != "") 
           {
            $image = $request->image6;
            $image6 = $image->store('upload');
           }
           else{
            $image6 = "";
          }
          if($request->image7 != "") 
           {
            $image = $request->image7;
            $image7 = $image->store('upload');
           }
           else{
            $image7 = "";
          }
          
        $Masters = Master::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5,
            'image6' => $image6,
            'image7' => $image7,
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
      ]);
        return redirect()->back();
        
    }
    public function updateimgpost7(Request $request, $ms_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Master::find($ms_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Master::find($ms_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Master::find($ms_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Master::find($ms_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          if($request->image5 != "") 
           {
            $image = $request->image5;
            $image5 = $image->store('upload');
            $passport= \App\Master::find($ms_id);
            $passport->image5=$image5;
            $passport->save();
           }
           else{
           
          }
          if($request->image6 != "") 
           {
            $image = $request->image6;
            $image6 = $image->store('upload');
            $passport= \App\Master::find($ms_id);
            $passport->image6=$image6;
            $passport->save();
           }
           else{
           
          }
          if($request->image7 != "") 
           {
            $image = $request->image7;
            $image7 = $image->store('upload');
            $passport= \App\Master::find($ms_id);
            $passport->image7=$image7;
            $passport->save();
           }
           else{
           
          }
      return redirect()->back();
    }
    public function publishpost7(Request $request, $ms_id)
    {
        
        $passport= \App\Master::find($ms_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    /*------------------------------------------Model 8-----------------------------------------------*/
    public function addpot8()
    {
        $Category = Category::get();
        return view('/add-post-8', compact('Category'));
    }
    public function editpot8($md_id)
    {
        
        $Meditations = Meditation::findOrFail($md_id);
        return view('/edit-post-8', compact('Meditations'));

    }
    public function updatepost8(Request $request, $md_id)
    {
        
        $passport= \App\Meditation::find($md_id);
        $passport->title=$request->get('title');
        $passport->slug=$request->get('slug');
        $passport->short_desc=$request->get('short_desc');
        $passport->editor1=$request->get('editor1');
        $passport->editor2=$request->get('editor2');
        $passport->editor3=$request->get('editor3');
        $passport->editor4=$request->get('editor4');
        $passport->editor5=$request->get('editor5');
        $passport->editor6=$request->get('editor6');
        $passport->category=$request->get('category');
        $passport->seo_title=$request->get('seo_title');
        $passport->seo_desc=$request->get('seo_desc');
        $passport->seo_keywords=$request->get('seo_keywords');
        $passport->tags=$request->get('tags');
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
    public function destroy8($md_id)
    {
        
        $Posts = Meditation::findOrFail($md_id);
        $Posts->delete();

        
        return redirect()->back();
    }
    public function addpost8(Request $request)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
           }
           else{
            $image1 = "";
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
           }
           else{
            $image2 = "";
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
           }
           else{
            $image3 = "";
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
           }
           else{
            $image4 = "";
          }
          
          
        $Meditations = Meditation::create([
            'title'=> $request['title'],
            'slug'=> $request['slug'],
            'short_desc' => $request['short_desc'],
            'editor1'=> $request['editor1'],
            'editor2'=> $request['editor2'],
            'editor3'=> $request['editor3'],
            'editor4'=> $request['editor4'],
            'editor5'=> $request['editor5'],
            'editor6'=> $request['editor6'],
            'category' => $request['category'],                 
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            
            'seo_title' => $request['seo_title'],
            'seo_desc' => $request['seo_desc'],
            'seo_keywords' => $request['seo_keywords'],
            'tags' => $request['tags'],
            'status' => "New",
            'created_by' => Auth::User()->id,
        ]);
        return redirect()->back();
        
    }
    public function updateimgpost8(Request $request, $md_id)
    {
          if($request->image1 != "") 
           {
            $image = $request->image1;
            $image1 = $image->store('upload');
            $passport= \App\Meditation::find($md_id);
            $passport->image1=$image1;
            $passport->save();
           }
           else{
            
          }
          if($request->image2 != "") 
           {
            $image = $request->image2;
            $image2 = $image->store('upload');
            $passport= \App\Meditation::find($md_id);
            $passport->image2=$image2;
            $passport->save();
           }
           else{
            
          }
          if($request->image3 != "") 
           {
            $image = $request->image3;
            $image3 = $image->store('upload');
            $passport= \App\Meditation::find($md_id);
            $passport->image3=$image3;
            $passport->save();
           }
           else{
            
          }
          if($request->image4 != "") 
           {
            $image = $request->image4;
            $image4 = $image->store('upload');
            $passport= \App\Meditation::find($md_id);
            $passport->image4=$image4;
            $passport->save();
           }
           else{
            
          }
          
        return redirect()->back();
    }
    public function publishpost8(Request $request, $md_id)
    {
        
        $passport= \App\Meditation::find($md_id);
        $passport->status=$request->get('status');
        
        $passport->updated_by=Auth::User()->id;
        $passport->save();

        
        return redirect()->back();
    }
}
