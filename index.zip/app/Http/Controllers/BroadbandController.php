<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Broadband;
use Response;
class BroadbandController extends Controller
{
	public $successStatus = 200;

    public function get(Request $request)
    {
    	$data = $request->data;

                 $drivers = Broadband::where('prov_name', 'Like', '%'.$data.'%')->orwhere('product', 'Like', '%'.$data.'%')->get();
                 if (count($drivers) >= 1) {
                 	$success['Broadband'] = Broadband::where('prov_name', 'Like', '%'.$data.'%')->orwhere('product', 'Like', '%'.$data.'%')->get();
                 	 return response()->json(['success' => $success], $this->successStatus);
                 }
                 else{
                 	$message = "Sorry. Data Not Found.";
                 	return Response::json([
                     'data' => $message
                     ]);

                 }

        
    }
}
