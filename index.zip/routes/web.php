<?php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\UploadRequest;
use Illuminate\Support\Facades\DB; 
use App\Energy;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	$Products = Energy::get();
    return view('welcome', compact('Products'));
});

Auth::routes();


