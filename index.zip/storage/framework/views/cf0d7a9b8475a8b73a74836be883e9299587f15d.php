<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">
      <title>Blogs List | Yogi360</title>
   </head>
   <body>
       <header class="fixed-top">
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>" class="innerlogo"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
               <ul class="navbar-nav text-uppercase mr-auto mt-2 mt-lg-0">
                  <li class="nav-item active">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/yoga-101')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">meditation</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">asana</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">pranayam</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mudra</a></li>
                  <li class="divider"></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mystic</a></li>
                 </ul>
               </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/practice')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">beginner</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">intermediate</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">advanced</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">anatomy</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/lifestyle')); ?>">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/travel')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">widespread</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">ttc</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">courses</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">retreats</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">wellness</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">trends</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">studios</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/logical')); ?>">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/inspiring')); ?>">inspiring</a>
                  </li>
               </ul>

               <form action="<?php echo e(url('/search')); ?>" method="POST" class="form-inline my-2 my-lg-0">
               <?php echo e(csrf_field()); ?>

                 <div class="search__wrapper">
                   <input type="text" name="search" required="required" placeholder="Search category..." class="search__field">
                   <button type="Submit" id="Submit" name="Submit" class="fa fa-search search__icon"></button>
                 </div>
               </form>
            </div>
         </nav>
      </header>
      <section class="banner-slide-listing p-0 m-0">
         <div class="container-fluid p-0">
      <div class="row no-gutters">
            <div class="col-lg-4 col-md-12 col-sm-12 liststatic">
               <div class="text-inner">
                  <div class="desc text-center text-uppercase">
                     <h2 class="listingbannertext">Welcome to the world of <i>Yogi360!</i></h2>
           <div class="spacecontent"></div>
                     <p class="text-justify">You are going to explore what you know already but have forgotten. Our prime intention is to make you familiar with your true nature. Come, let's explore more about yourself... <a href="https://yogi360.com/"></a></p>
                  </div>
               </div>
            </div>
            <div class="col-lg-8 col-md-12 col-sm-12 regularlistbanner">
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l1.png')); ?>"></a>
               
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l2.png')); ?>" alt=""></a>
                 
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l3.png')); ?>" alt=""></a>
                 
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l4.png')); ?>" alt=""></a>

                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l5.png')); ?>" alt=""></a>
                 
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l6.png')); ?>" alt=""></a>
                
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
            </div>
         </div>
         
         </div>
      </section>
      
    
    <div class="clear"></div>
<div id="staticDynamic p-0 m-0">
    <div class="container-fluid p-0">
      <div class="row no-gutters">
        <div class="col lg-12 col-md-12 col-sm-12">
        <main role="main" class="probootstrap-main">
<div class="row no-gutters">
<?php $__currentLoopData = $Posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Post->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Post->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-1/'.$Post->pst_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $Emotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Emotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Emotion->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Emotion->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-3/'.$Emotion->emt_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $Titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Title->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Title->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-4/'.$Title->tt_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $Blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Blog->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Blog->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-5/'.$Blog->bg_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $Breathings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Breathing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Breathing->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Breathing->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-6/'.$Breathing->br_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $Foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Food->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Food->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-7/'.$Food->fd_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $Masters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Master->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Master->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-8/'.$Master->ms_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $Meditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Meditation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">
 <div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/storage/app/'.$Meditation->image1)); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Meditation->title); ?></h5>
    
    <div class="metatag">
      <span class="meta-links"><a href="<?php echo e(url('/blog-details-9/'.$Meditation->md_id)); ?>">READ MORE </a></span>
    </div>
  </div>
 </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="container-fluid d-md-none">
<div class="row">
<div class="col-md-12">
<ul class="list-unstyled d-flex probootstrap-aside-social">
<li><a href="#" class="p-2"><span class="icon-twitter"></span></a></li>
<li><a href="#" class="p-2"><span class="icon-instagram"></span></a></li>
<li><a href="#" class="p-2"><span class="icon-dribbble"></span></a></li>
</ul>
<p>&copy; 2020 <a href="https://www.yogi360.com/" target="_blank">Yogi360</a>. <br> All Rights Reserved.</p>
</div>
</div>
</div>
</main>
        </div>
      </div><!---end of row -------->
    
    </div>
</div>

    <!----------end of static and dynamic column-------------->
      <div class="heightspace"></div>
<footer class="footer-area">
<div class="container">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="https://www.yogi360.com/">Yogi360</a></li>
<li><a href="https://www.yogi360live.com/">Yogi360 Live</a></li>
<li><a href="https://www.yogi360ayurveda.com/">Yogi360 Ayurveda</a></li>
<li><a href="https://www.yogi360retreats.com/">Yogi360 Retreat</a></li>
<li><a href="https://www.yogi360jobs.com">Yogi360 Jobs</a></li>
<li><a href="https://www.yogi360store.com">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/yoga-101')); ?>">Yoga 101 </a></li>
<li><a href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
<li><a href="<?php echo e(url('/logical')); ?>">Logical</a></li>
<li><a href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
<li><a href="<?php echo e(url('/travel')); ?>">Travel</a></li>
<li><a href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
<li><a href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/blog-details-1/1')); ?>">Emotion | Body | Yoga : A connection that you need to know</a></li>
<li><a href="<?php echo e(url('/blog-details-3/1')); ?>">Teach your students by Wisdom and not by Hand</a></li>
<li><a href="<?php echo e(url('/blog-details-4/1')); ?>">Physical Training or Yoga- Which is more important in school?</a></li>
<li><a href="<?php echo e(url('/blog-details-5/1')); ?>">How does a mantra purify emotional lifestyles?</a></li>
<li><a href="<?php echo e(url('/blog-details-6/1')); ?>">Breathing purifies your emotions: Did you know it?</a></li>
<li><a href="<?php echo e(url('/blog-details-7/2')); ?>">Yoga practitioners diet: Are you eating what your body demands?</a></li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/#about')); ?>">About Us</a></li>
<li><a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row">

<p class="footer-text mx-auto">
Copyright © 2020 Yogi360, All rights reserved Powered By<a href="https://yogicconnection.com" target="_blank">Yogi360</a>
</p>
</div>
<div class="row pb-3">
<div class="footer-social d-flex mx-auto">
<a href="#"><img src="<?php echo e(asset('/public/images/face.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/insta.png')); ?>"></a>
<a href="#"><img src="<?php echo e(asset('/public/images/link.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/tweet.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/you.png')); ?>"></i></a>
</div>
</div>
</div>

</footer>
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
      <script src="<?php echo e(asset('/public/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin ------------>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->
  <script src="<?php echo e(asset('/public/js/slider.js')); ?>" type="text/javascript" charset="utf-8"></script>

   </body>
</html>