<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/new12/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/new12/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/new12/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">
      <title><?php echo e($Emotions->title); ?></title>
   </head>
   <body class="transparentblog">
      <header>
         <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="#"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>" class="innerlogo"></a>
			
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul class="navbar-nav text-uppercase mr-auto mt-2 mt-lg-0">
                  <li class="nav-item active">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/yoga-101')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">meditation</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">asana</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">pranayam</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mudra</a></li>
                  <li class="divider"></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mystic</a></li>
                 </ul>
                </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/practice')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">beginner</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">intermediate</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">advanced</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">anatomy</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/lifestyle')); ?>">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/travel')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">widespread</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">ttc</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">courses</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">retreats</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">wellness</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">trends</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">studios</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/logical')); ?>">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/inspiring')); ?>">inspiring</a>
                  </li>
              </ul>
               
            </div>
         </nav>
      </header>
	  <!-- Main -->
		 <section class="opacbloging">
				
				<h2 class="headingtext justify-content-center text-center"><?php echo e($Emotions->title); ?></h1>
				<!-- One -->
					<section class="wrapper style1 shadow p-0">

						<div class="container-fluid p-0">
							<img class="img-fluild d-block w-100" src="<?php echo e(asset('/storage/app/'.$Emotions->image1)); ?>" alt="" />
						</div>

						
					</section>

				<!-- Two -->

				<!-- Three -->
					<section class="wrapper">
					<div class="container-fluid bgtrans">
					<?php echo $Emotions->editor1; ?>

					</div>
											<div class="container-fluid">
											<div class="row">
											
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 p-0 mt-5"><img src="<?php echo e(asset('/storage/app/'.$Emotions->image2)); ?>" class="img-fluid d-block w-100" alt="" /></div>
							
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 inner text-justify">
								<?php echo $Emotions->editor2; ?>

								
							</div>
							</div><!---end of row -->
						</div>
						
					
						
						<div class="container-fluid">
						<div class="row">
							
							<div  class="col-lg-6 col-md-12 col-sm-12 col-xs-12 inneralt text-justify">
                            <?php echo $Emotions->editor3; ?>


							</div>
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 p-0"><img src="<?php echo e(asset('/storage/app/'.$Emotions->image3)); ?>" class="img-fluid w-100 d-block" alt="" /></div>
							</div>
						</div>
						<div class="container-fluid bgtrans">
						<?php echo $Emotions->editor4; ?>


						</div>
						<div class="container-fluid">
							<div class="row">
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 p-0 mt-4"><img src="<?php echo e(asset('/storage/app/'.$Emotions->image4)); ?>" class="img-fluid w-100 d-block" alt="" /></div>
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 inner text-justify">
								<?php echo $Emotions->editor5; ?>

								
							</div>
							</div>
						</div>
						
					
						
						<div class="container-fluid">
							<div class="row">
							<div  class="col-lg-6 col-md-12 col-sm-12 col-xs-12 inneralt text-justify">
                              <?php echo $Emotions->editor6; ?>


							</div>
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 p-0"><img src="<?php echo e(asset('/storage/app/'.$Emotions->image5)); ?>" class="img-fluid w-100 d-block" alt="" /></div>
							</div><!-------------end of row-------------->
						</div>
                        <div class="container-fluid bgtrans">
                        <?php echo $Emotions->editor7; ?>

                        </div>

						<div class="container-fluid mt-5">
						<div class="row">
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 p-0"><img src="<?php echo e(asset('/storage/app/'.$Emotions->image6)); ?>" class="img-fluid w-100 d-block" alt="" /></div>
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 inner text-justify">
								<?php echo $Emotions->editor8; ?>

								

							</div>
							</div>
						</div>
						<div class="container-fluid">
							<div class="row">
							<div  class="col-lg-6 col-md-12 col-sm-12 col-xs-12 inneralt text-justify">
							<?php echo $Emotions->editor9; ?>

																
							</div>
							<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 p-0"><img src="<?php echo e(asset('/storage/app/'.$Emotions->image7)); ?>" class="img-fluid w-100 d-block" alt="" /></div>
							</div>
						</div>
						<div class="container-fluid bgtrans">
														
						<?php echo $Emotions->editor10; ?>

                        </div>
					</section>

		</section>
	
	  
	  
	  <hr class="thickbar">
	  <footer class="footer-area">
<div class="container">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="https://www.yogi360.com/">Yogi360</a></li>
<li><a href="https://www.yogi360live.com/">Yogi360 Live</a></li>
<li><a href="https://www.yogi360ayurveda.com/">Yogi360 Ayurveda</a></li>
<li><a href="https://www.yogi360retreats.com/">Yogi360 Retreat</a></li>
<li><a href="https://www.yogi360jobs.com">Yogi360 Jobs</a></li>
<li><a href="https://www.yogi360store.com">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/yoga-101')); ?>">Yoga 101 </a></li>
<li><a href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
<li><a href="<?php echo e(url('/logical')); ?>">Logical</a></li>
<li><a href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
<li><a href="<?php echo e(url('/travel')); ?>">Travel</a></li>
<li><a href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
<li><a href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/blog-details-1/1')); ?>">Emotion | Body | Yoga : A connection that you need to know</a></li>
<li><a href="<?php echo e(url('/blog-details-3/1')); ?>">Teach your students by Wisdom and not by Hand</a></li>
<li><a href="<?php echo e(url('/blog-details-4/1')); ?>">Physical Training or Yoga- Which is more important in school?</a></li>
<li><a href="<?php echo e(url('/blog-details-5/1')); ?>">How does a mantra purify emotional lifestyles?</a></li>
<li><a href="<?php echo e(url('/blog-details-6/1')); ?>">Breathing purifies your emotions: Did you know it?</a></li>
<li><a href="<?php echo e(url('/blog-details-7/2')); ?>">Yoga practitioners diet: Are you eating what your body demands?</a></li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="#">About Us</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row justify-content-center pb-3">


Copyright © 2020 Yogi360, <br>All rights reserved Powered By Yogi360

</div>

<div class="row pb-3">
<div class="footer-social d-flex mx-auto">
<a href="#"><img src="<?php echo e(asset('/public/images/face.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/insta.png')); ?>"></a>
<a href="#"><img src="<?php echo e(asset('/public/images/link.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/tweet.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/you.png')); ?>"></i></a>
</div>
</div>
</div>

</footer>
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
      <script src="<?php echo e(asset('/public/new12/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin ------------>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->
	<script src="<?php echo e(asset('/public/new12/js/slider.js')); ?>" type="text/javascript" charset="utf-8"></script>

   </body>
</html>

		
	