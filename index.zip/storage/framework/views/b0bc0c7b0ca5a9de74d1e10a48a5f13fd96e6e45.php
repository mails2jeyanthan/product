<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Welcome To | ADMIN DASHBOARD</title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="<?php echo e(asset('/public/dashboard/plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo e(asset('/public/dashboard/plugins/node-waves/waves.css')); ?>" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo e(asset('/public/dashboard/plugins/animate-css/animate.css')); ?>" rel="stylesheet" />

    <!-- Morris Chart Css-->
    <link href="<?php echo e(asset('/public/dashboard/plugins/morrisjs/morris.css')); ?>" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo e(asset('/public/dashboard/css/dashstyle.css')); ?>" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="<?php echo e(asset('/public/dashboard/css/themes/all-themes.css')); ?>" rel="stylesheet" />
    <style>
img{
  max-width:180px;
}
input[type=file]{
padding:10px;
background:#2d2d2d;}
</style>
</head>

<body class="theme-red">
    <?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD</h2>
            </div>

            <!-- Widgets -->
            <div class="row clearfix">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">playlist_add_check</i>
                        </div>
                        <div class="content">
                            <div class="text">SEO STATUS</div>
                            <div class="number count-to" data-from="0" data-to="125" data-speed="15" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">help</i>
                        </div>
                        <div class="content">
                            <div class="text">POST PUBLISHED</div>
                            <div class="number count-to" data-from="0" data-to="257" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">forum</i>
                        </div>
                        <div class="content">
                            <div class="text">NEW POST</div>
                            <div class="number count-to" data-from="0" data-to="243" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">person_add</i>
                        </div>
                        <div class="content">
                            <div class="text">TOTAL COUNT</div>
                            <div class="number count-to" data-from="0" data-to="1225" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
            </div>

                       <div class="row clearfix">
                <!-- Visitors -->
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <div class="card">
                        <div class="body">

<form action="<?php echo e(url('/save-post-5')); ?>" method="POST" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-12 col-form-label">Title (h1 TAG) *</label>
    <div class="col-sm-12">
      <input type="text" name="title" class="form-control"  placeholder="Title" required="required">
    </div>
  </div>
  <div class="form-group">
    <label for="">Category *</label>
    <input type="text" name="category" class="form-control"  placeholder="Category" required="required">
    
    
</div>
<div class="form-group row">
    <label class="col-sm-12 col-form-label">Slug (Page URL) *</label>
    <div class="col-sm-12">
      <input type="text" class="form-control" name="slug" placeholder="Enter page URL" required="required">
    </div>
  </div>
  <div class="form-group">
<div class="fileupload">
  <label for="image1">Image 1 (size 1110 * 496) *</label>
  <input type="file" name="image1" id="image1" onchange="readURL1(this);" required="required">
</div>

<img id="blah1" src="<?php echo e(asset('/public/dashboard/images/user.jpg')); ?>" alt="your image" />
</div>
    <div class="form-group">
    <label for="exampleFormControlTextarea1">Description Part 1  *</label>
    <textarea name="editor1" required="required"></textarea> <br>
  
  </div>
  <div class="form-group">
<div class="fileupload">
  <label for="image2">Image 2 (size 400 * 800)</label>
  <input type="file" name="image2" id="image2" onchange="readURL2(this);">
</div>

<img id="blah2" src="<?php echo e(asset('/public/dashboard/images/user.jpg')); ?>" alt="your image" />
</div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Description Part 2  *</label>
    <textarea name="editor2" required="required"></textarea> <br>
  
  </div>
  <div class="form-group">
<div class="fileupload">
  <label for="image3">Image 3 (size 400 * 800)</label>
  <input type="file" name="image3" id="image3" onchange="readURL3(this);">
</div>

<img id="blah3" src="<?php echo e(asset('/public/dashboard/images/user.jpg')); ?>" alt="your image" />
</div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Description Part 3  *</label>
    <textarea name="editor3" required="required"></textarea> <br>
  
  </div>
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Description Part 4  *</label>
    <textarea name="editor4" required="required"></textarea> <br>
  
  </div>
<div class="form-group row">
    <label class="col-sm-12 col-form-label">SEO Title</label>
    <div class="col-sm-12">
      <input type="text" name="seo_title" class="form-control" placeholder="SEO Title ">
    </div>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">seo description</label>
    <textarea class="form-control" name="seo_desc" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
    <div class="form-group row">
    <label class="col-sm-12 col-form-label">SEO Keywords</label>
    <div class="col-sm-12">
      <input type="text" name="seo_keywords" class="form-control" placeholder="Keywords ">
    </div>
  </div>
    
    <div class="form-group">
    <label for="exampleFormControlTextarea1">TAGS</label>
    <textarea class="form-control" name="tags" rows="3"></textarea>
  </div>

  <div class="form-group row">
    <div class="col-sm-5">
    <button type="submit" class="managebutton">ADD POST</button>
      
    </div>
        <div class="col-sm-5">
      
    </div>
  </div>
</form>
                        </div>
                    </div>
                </div>
                <!-- #END# Visitors -->

                <!-- Answered Tickets -->
                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="card">
                        <div class="body bg-teal">
                            <div class="font-bold m-b--35">How many Category POSTED?</div>
                            <ul class="dashboard-stat-list">
                                <li>
                                    TODAY
                                    <span class="pull-right"><b>12</b> <small>POST</small></span>
                                </li>
                                <li>
                                    YESTERDAY
                                    <span class="pull-right"><b>15</b> <small>POST</small></span>
                                </li>
                                <li>
                                    LAST WEEK
                                    <span class="pull-right"><b>90</b> <small>POST</small></span>
                                </li>
                                <li>
                                    LAST MONTH
                                    <span class="pull-right"><b>342</b> <small>POST</small></span>
                                </li>
                                <li>
                                    LAST YEAR
                                    <span class="pull-right"><b>4 225</b> <small>POST</small></span>
                                </li>
                                <li>
                                    ALL
                                    <span class="pull-right"><b>8 752</b> <small>POST</small></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- #END# Answered Tickets -->
            </div>

            
            </div>
        </div>
    </section>

</script>
<script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>  
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <!-- Jquery Core Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/bootstrap/js/bootstrap.js')); ?>"></script>

    <!-- Select Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/bootstrap-select/js/bootstrap-select.js')); ?>"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/node-waves/waves.js')); ?>"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/jquery-countto/jquery.countTo.js')); ?>"></script>

    <!-- Morris Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/dashboard/plugins/morrisjs/morris.js')); ?>"></script>

    <!-- ChartJs -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/chartjs/Chart.bundle.js')); ?>"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/flot-charts/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/dashboard/plugins/flot-charts/jquery.flot.resize.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/dashboard/plugins/flot-charts/jquery.flot.pie.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/dashboard/plugins/flot-charts/jquery.flot.categories.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/dashboard/plugins/flot-charts/jquery.flot.time.js')); ?>"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/jquery-sparkline/jquery.sparkline.js')); ?>"></script>

    <!-- Custom Js -->
    <script src="<?php echo e(asset('/public/dashboard/js/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/dashboard/js/pages/index.js')); ?>"></script>

    <!-- Demo Js -->
    <script src="<?php echo e(asset('/public/dashboard/js/demo.js')); ?>"></script>
    <script>
     function readURL1(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah1')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        function readURL2(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah2')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        function readURL3(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah3')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        function readURL4(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah4')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        function readURL5(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah5')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
           CKEDITOR.replace('editor1');  
    CKEDITOR.replace('editor2'); 
    CKEDITOR.replace('editor3');
    CKEDITOR.replace('editor4'); 
  
    function getData() {  
        //Get data written in first Editor   
        var editor_data = CKEDITOR.instances['editor1'].getData();  
        //Set data in Second Editor which is written in first Editor  
        CKEDITOR.instances['editor1'].setData(editor_data);  
    }
    function getData() {  
        //Get data written in first Editor   
        var editor_data = CKEDITOR.instances['editor2'].getData();  
        //Set data in Second Editor which is written in first Editor  
        CKEDITOR.instances['editor2'].setData(editor_data);  
    }
    function getData() {  
        //Get data written in first Editor   
        var editor_data = CKEDITOR.instances['editor3'].getData();  
        //Set data in Second Editor which is written in first Editor  
        CKEDITOR.instances['editor3'].setData(editor_data);  
    }
    function getData() {  
        //Get data written in first Editor   
        var editor_data = CKEDITOR.instances['editor4'].getData();  
        //Set data in Second Editor which is written in first Editor  
        CKEDITOR.instances['editor4'].setData(editor_data);  
    }
</script>
</body>

</html>
