<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">

      <title>Terms and Conditions</title>


</head>
<body onload="document.body.style.opacity='1'" class="grayshade">
      <header class="fixed-top">
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>" class="innerlogo"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
               <ul class="navbar-nav text-uppercase mr-auto mt-2 mt-lg-0">
                  <li class="nav-item active">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/yoga-101')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">meditation</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">asana</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">pranayam</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mudra</a></li>
                  <li class="divider"></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mystic</a></li>
                 </ul>
               </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/practice')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">beginner</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">intermediate</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">advanced</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">anatomy</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/lifestyle')); ?>">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/travel')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">widespread</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">ttc</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">courses</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">retreats</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">wellness</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">trends</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">studios</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/logical')); ?>">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/inspiring')); ?>">inspiring</a>
                  </li>
               </ul>
               
            </div>
         </nav>
      </header>
        
     
<section class="blogtextwrap m-0">
<div class="marg container-fluid py-5 bg-white insetpadding shadow">
<div class="row align-items-center">
<div class="col-md-12 col-lg-12" data-aos="fade-up">
<div class="paracontent">
<h1 class="text-center">Terms and Conditions</h1>
   <h3> Support</h3>
<p>We would like to make your experience of the use of our platform as positive as possible. In the case that you do encounter any problems when using our service, please let us know. We are passionate about offering customer care. Please note that this support is never a legal obligation and that we do not take on more obligations than provided in these terms of use.</p>
<h2>Terms of Use</h2>
<p>These terms of use – that may be amended at our discretion – apply to all our services that are provided to you online directly or indirectly. By browsing our website or making use of our website, you acknowledge and agree that you have read the below terms of use and you agree to these terms of use. We advise you to carefully read the terms of use, so you fully understand the rights and obligations you have in relation to your use of the platform. You can access the terms of use through this hyperlink [Terms and Conditions].</p>

<h3>General</h3>
<ul>
  <li>1.1 These terms of use ("Terms of Use") apply to every use made of the platform. On the platform, as developed by Yogi360, you can read and enjoy our content or even compare and book most needed Yoga / Ayurveda Insurances ("Platform").</li>
  <li>1.2 If you keep using the Platform after the Terms of Use have been amended/supplemented, you unconditionally agree to the amended/supplemented Terms of Use. If you do not wish to accept the amendments and/or supplements, your only remedy is to cease using the Platform.</li>
  <li>1.3 To the best of its ability, Yogi360 will make efforts to provide the Platform with due care. You accept that the Platform, only contains the functionalities and other characteristics as it contains at the moment of your use ("as is" and "as available"). Each and every use of the Platform is for your own risk and responsibility.</li>
  <li>1.4 Yogi360 is at all times, without in any way becoming liable to you, entitled to make procedural and technical alterations and/or improvements to the Platform.</li>
</ul>
<p>In other words:</p>
<p>"Sometimes it is necessary for us to make changes or improvements to our service or to our terms of use. However, we will do everything in our power to make sure your use of the platform goes as smoothly as possible. Please be aware that your use of our platform is for your own risk and responsibility."</p>


<h3>Use of the Platform</h3>
<ul>
  <li>2.1 In using the Platform, you can view all our knowledgeable Content and offers published on Insurances. A booking placed through the Platform forms a binding agreement between you and the Organizer (Insurance broker). Requests, however, are non-binding. If you have any questions, complaints or remarks about an Organizer, an Experience Offer, you can contact Yogi360 through the Platform.</li>
  <li>2.2 The Experience Offers are subject to the Organizer’s terms and conditions, as well as all agreements between you and the Organizer. Yogi360 shall never become a party to an agreement between an Organizer and you. We advise you to carefully read the Organizer’s terms and conditions, since they may entail legal obligations and it is your responsibility to adhere to such obligations. Yogi360 accepts no responsibility whatsoever for any decisions made by you based on the content of Yogi360 and/or the Organizers on the Platform, unless stated otherwise in these Terms of Use.</li>
  <li>2.3 You are solely responsible and liable for the content you submit. Since you are able to upload content to the Platform without restriction, you warrant that this content is lawful and does not infringe upon any party’s intellectual property rights, privacy rights or any other rights and you indemnify Yogi360 from any third party’s claim in this respect. You also warrant that you do not submit content which involves any illegal activities or activities that are contrary to morality or public order, which includes, but is not limited to content that relates to hate speech, is intended to promote or sell drugs or firearms, is violent in any way or qualifies as or transmits unwanted or unsolicited material or content (spam). We do not warrant that your content will be correctly, completely and/or continuously available on the Platform.</li>
  <li>2.4 Finally, when using our Platform you shall adhere to the following rules. You may not:</li>
</ul>
<p>use the Platform with a device that contains viruses, Trojan horses, worms, bots or other malicious software that can alter, damage, disable, infect or delete the Platform or make it unavailable or inaccessible;</p>
<p>deliberately involve manual or automated software, devices, or other processes to "crawl", "spider" or scrape any content on the Platform;
reproduce or decompile the Platform or to apply reverse engineering to it, unless permitted by mandatory law;</p>
<p>remove and/or to circumvent security measures or technical limitations (including limitations to the use) of the Platform.</p>
<h3>In other words:</h3>
<p>"After you’ve chosen and entered all of your correct personal data, you will engage in a contract with the actual organizer of the Insurance Plan. Yogi360 can in no way be held responsible if issues (however unlikely) arise between you and the organizer, but we will help you in resolving the issue. Also, you cannot use our platform in any inappropriate way, so no spreading viruses, hacking or spamming etc."</p>
<h3>IP Rights</h3>
<ul>
  <li> 4.1 All intellectual property rights relating to the Platform, including copyrights, trade mark rights, patent rights, design rights, trade name rights, database rights, and neighbouring rights, as well as rights to knowhow ("IP Rights"), are owned by Yogi360, its licensors or our Organizers. Nothing in these Terms of Use constitutes the transfer of any IP Rights from Yogi360 to you. You are solely granted a right to use the Platform if you act in accordance with the Terms of Use.</li>
  <li>4.2 By uploading reviews and other content, you grant Yogi360 a royalty-free, worldwide, non- exclusive, sublicensable and transferable right to reproduce this content and make it available on the Platform, including the right to use (parts of) this content, for promotional purposes and other services in connection with the Platform.</li>
  <li>4.3 You represent and warrant that you have all rights to grant the licenses as laid down in Article</li>
  <li>4.2 of these Terms of Use, without infringing or violating any third party rights, including but not limited to, any privacy rights, publicity rights, IP Rights or any other proprietary rights. You indemnify Yogi360 against any and all third party claims, based upon any alleged infringement of such third party rights in relation to the content you submitted.</li>
</ul>
<h3>In other words:</h3>
<p>"Please respect our intellectual property rights and the rights of the Insurance organizers. We do the same with the content you upload; your content will preserve whatever copyright and other IP rights it had when uploading to our platform."</p>


<h3>Privacy</h3>
<ul>
  <li>5.1 In order to make use of the Platform it is required that you provide Yogi360 with personal information such as your name and e-mail address. The provision of this information is subject to legislation in respect of privacy. Yogi360 only uses your personal data in accordance with the Privacy Policy.</li>
  <li>5.2 In order to submit a Request or make a Reservation, you may be required to provide personal data to an Organizer. The Organizer is responsible for the processing of such data and shall do so in accordance with its own privacy statement. We shall not be liable for any damages incurred by you due to the processing of your personal data by an Organizer.</li>
</ul>
<h3>In other words:</h3>
<p>"We take your privacy very seriously. We only gather (personal) data for the purpose of providing you the service you need. We take appropriate measures to safeguard your personal data. After a payment booking for Insurance or subscribing to our blog content; making the organizer is responsible for handling of your personal information. For more info check out our Privacy Policy."</p>
<h3>Liability</h3>
<ul>
  <li>6.1 Yogi360’s liability, whether based upon (attributable) default, unlawful act or any other ground, is limited to direct damages only and shall not exceed the amount of EUR 250 in a contracting year per event (a sequence of events will be regarded as one event).</li>
  <li>6.2 Direct damage shall solely mean:
Damage to property;
Reasonable expenses incurred to prevent or limit direct damages that could be expected from the event on which is the liability is based, and
reasonable costs incurred in determining the cause of the damage.</li>
  <li>6.3 Any liability on Yogi360’s part for damages other than direct damage, including but not limited to indirect loss, consequential loss, loss and/or damage of data or content, loss of profit and loss of revenue, loss of savings, reduced goodwill, damage by business interruption and damage as a result of claims from third parties is excluded.</li>
  <li>6.4 The restrictions mentioned in the preceding paragraphs of this article will lapse if and in so far as the damage is the result of intentional or wilful recklessness on the part of Yogi360 or its managers ("own actions").</li>
</ul>
<h3>In other words:</h3>
<p>"In the unlikely event of something going really wrong while using our services, we cannot be held liable to pay damages of over EUR 250, except in the unthinkable event of us causing a problem intentionally or acted recklessly."</p>


<h3>Applicable law and competent court</h3>
<p>The Terms of Use and the use of the Platform are governed by Indian law. Any and all disputes arising from or related any agreement between Parties will be brought before the competent court in India.</p>
<p>Yogi360 may transfer rights and obligations arising from these Terms and Conditions to third parties and will notify you of this. The Organizer is not permitted to transfer any right derived from an Account to third parties without Yogi360's prior written consent.</p>
<p>If at any time any provision of these Terms and Conditions is or becomes illegal, void or invalid for any reason whatsoever, such invalidity shall not affect the validity of the remainder of these Terms and Conditions and such invalid provision shall be replaced by another provision which, being valid in all respects, shall have an effect as close as possible to that of the replaced provision. These Terms and Conditions and the use of the Platform are governed by Indian law.</p>
<p>Any and all disputes arising from or related to any agreement between Parties will be brought before the competent court in India.</p>
    
</div>

</div>
</div>
</div>

</section>
<footer class="footer-area">
<div class="container">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="https://www.yogi360.com/">Yogi360</a></li>
<li><a href="https://www.yogi360live.com/">Yogi360 Live</a></li>
<li><a href="https://www.yogi360ayurveda.com/">Yogi360 Ayurveda</a></li>
<li><a href="https://www.yogi360retreats.com/">Yogi360 Retreat</a></li>
<li><a href="https://www.yogi360jobs.com">Yogi360 Jobs</a></li>
<li><a href="https://www.yogi360store.com">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/yoga-101')); ?>">Yoga 101 </a></li>
<li><a href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
<li><a href="<?php echo e(url('/logical')); ?>">Logical</a></li>
<li><a href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
<li><a href="<?php echo e(url('/travel')); ?>">Travel</a></li>
<li><a href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
<li><a href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/blog-details-1/1')); ?>">Emotion | Body | Yoga : A connection that you need to know</a></li>
<li><a href="<?php echo e(url('/blog-details-3/1')); ?>">Teach your students by Wisdom and not by Hand</a></li>
<li><a href="<?php echo e(url('/blog-details-4/1')); ?>">Physical Training or Yoga- Which is more important in school?</a></li>
<li><a href="<?php echo e(url('/blog-details-5/1')); ?>">How does a mantra purify emotional lifestyles?</a></li>
<li><a href="<?php echo e(url('/blog-details-6/1')); ?>">Breathing purifies your emotions: Did you know it?</a></li>
<li><a href="<?php echo e(url('/blog-details-7/2')); ?>">Yoga practitioners diet: Are you eating what your body demands?</a></li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/#about')); ?>">About Us</a></li>
<li><a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
<li><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li>
<li><a href="#">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row">

<p class="footer-text mx-auto">
Copyright © 2020 Yogi360, All rights reserved Powered By<a href="https://yogicconnection.com" target="_blank">Yogi360</a>
</p>
</div>
<div class="row pb-3">
<div class="footer-social d-flex mx-auto">
<a href="#"><img src="<?php echo e(asset('/public/images/face.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/insta.png')); ?>"></a>
<a href="#"><img src="<?php echo e(asset('/public/images/link.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/tweet.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/you.png')); ?>"></i></a>
</div>
</div>
</div>

</footer>

     <!---end of static and dynamic column-->
      <div class="heightspace"></div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->

      <script src="<?php echo e(asset('/public/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin -->
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->

   </body>
</html>