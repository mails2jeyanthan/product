<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">

      <title>Yoga Approved</title>


   </head>
   <body onload="document.body.style.opacity='1'">
      <header class="fixed-top">
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>" class="innerlogo"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
               <ul class="navbar-nav text-uppercase mr-auto mt-2 mt-lg-0">
                  <li class="nav-item active">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="#">meditation</a></li>
                  <li><a class="nav-link" href="#">asana</a></li>
                  <li><a class="nav-link" href="#">pranayam</a></li>
                  <li><a class="nav-link" href="#">mudra</a></li>
                  <li class="divider"></li>
                  <li><a class="nav-link" href="#">mystic</a></li>
                 </ul>
               </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="#">beginner</a></li>
                  <li><a class="nav-link" href="#">intermediate</a></li>
                  <li><a class="nav-link" href="#">advanced</a></li>
                  <li><a class="nav-link" href="#">anatomy</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="listing.html#staticDynamic">widespread</a></li>
                  <li><a class="nav-link" href="#">ttc</a></li>
                  <li><a class="nav-link" href="#">courses</a></li>
                  <li><a class="nav-link" href="#">retreats</a></li>
                  <li><a class="nav-link" href="#">wellness</a></li>
                  <li><a class="nav-link" href="#">trends</a></li>
                  <li><a class="nav-link" href="#">studios</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">inspiring</a>
                  </li>
               </ul>
               <form class="form-inline my-2 my-lg-0">
                  <div class="search__wrapper">
                     <input type="text" name="" placeholder="Search for..." class="search__field">
                     <button type="submit" class="fa fa-search search__icon"></button>
                  </div>
               </form>
            </div>
         </nav>
      </header>
	  	  <div class="container-fluid p-0 bannerback">
		<div class="bannerslide bannerface">
			<img src="<?php echo e(asset('/public/images/5.png')); ?>" class="img-responsive h-100">
		</div>
		<div class="bannerslide banner-absolute offset-lg-7">
			<div class="applyyellow">Emotion | Body | Yoga : </div> A connection that you need to know
		</div>
	  </div>
	<section class="photo">
		<div class="circle circle1 regular">
			<img src="<?php echo e(asset('/public/images/ayur3.jpg')); ?>">
			<img src="<?php echo e(asset('/public/images/ayur2.jpg')); ?>">
			<img src="<?php echo e(asset('/public/images/b1.jpg')); ?>">
			
		</div>
				<div class="letter eff1">			
			<span><b>S</b></span>		
	
		</div>

		<div class="paracontent">
		<h1> H1 Tradition of Ayurveda emphasizes on Spiritual Therapy </h1><br>
		<p>
Spirituality is a broad concept with room for many perspectives. Being spiritual is not about an individual or a family. Being spiritual is about the mass, a larger population.
Knowing about the history of Ayurveda may take you through thousands of years before anyone invented the placebo-controlled experiments. But how this ancient system held up to the modern sciences?  As per the ancient system of medicine, the general philosophy of health and wellness was the object of Ayurvedic medicine. It includes sleep, exercise, and even hygiene.  
 
The interesting part is Ayurveda was more of ‘Spiritual Therapy’. It was not an individualist treatment but a way of curing at a mass level.  Like, Lord Buddha, Jesus and Krishna never worked for one or two people. They have extended their hands to help the masses for a better life. Ayurveda as a method serves the physical, psychological and spiritual benefits. 

</p>
		</div>
		  <div class="spacecontent"></div>
		  <div class="spacecontent"></div>
		  	<h1 class="text-center"> H1 Importance of Ayurveda in recent times </h1>

												<div class="leftTriangle">
			
			
			<span><img src="<?php echo e(asset('/public/images/ayur5.jpg')); ?>"> </span>
			
		</div>
														<div class="rightTriangle">
			
			
			<span><img src="<?php echo e(asset('/public/images/ayur1.jpg')); ?>"> </span>
			
		</div>

		<div class="para2">
		
		<p>
		The World Health Organization showed consideration for the benefits of conventional medicines in the late 1970s, aiding in the global acceptance of Ayurveda. Ironically, in most developed countries like the United States of America grew after the evidence and awareness based on the Ayurvedic medicines which intricate less side effect, now known to be Ayurveda accepted countries. It is not unknown to us that Ayurveda does wonder to get over our illness.
</p>
		</div>
				  <div class="spacecontent"></div>
		  <div class="spacecontent"></div>
		  				  <div class="spacecontent"></div>
		  <div class="spacecontent"></div>
		  <h1 class="text-center"> H2 Ayurveda’s immunity boosting regains your strength every time </h1>
	
												<div class="circle oval">
			
			
			<span><img src="<?php echo e(asset('/public/images/destination-4.jpg')); ?>"> </span>
			
		</div>
		<br>

		<div class="para1">
		
		<p>
		Importance of Ayurveda although has shifted from time to time, but the Ayurveda’s immunity boosting ability has tuned stronger with time. When we talk about strong immunity that means even if you are closer to the virus affected person you’ll not be affected by it. Having an immunity of 100% will not help if you do not regain it.  
Ayurveda is not limited to medicinal herbal treatment. It is an ongoing process to regain immunity for making your foundation strong. Following Ayurvedic treatments will give you every possibility to refill your system every time you lose some of it and across the globe, has affected so many lives due to lack of immunity. WHO even proposes the fact that ‘if we can work on the building your immunity stronger with Ayurvedic help and Ayurvedic medicine, then there are fewer chances of getting affected by any outside virus.’
Example:
Kerala, known to be the paradise of Ayurveda, people were affected by Covid19 India; they went through the lockdown, start implementing traditional Ayurvedic roots. Ayurveda’s immunity boosting processes are seriously taken by the people here. This resulted in a fast cure and fewer effects on the people. The cases have slowed down; the recoveries are elevated, and the mortality rate is low. The focus is on healthy living based on the Ayurvedic tradition of Kerala has shown the best results in COVID-19 treatment. 
</p>
		</div>
						
					  <div class="spacecontent"></div>
		  <div class="spacecontent"></div>
		   <h1 class="text-center"> H1 WHO recognizes Ayurveda for building immunity worldwide </h1>
							<div class="star">
			
			
			<span><img src="<?php echo e(asset('/public/images/gif2.gif')); ?>" class="l1"> </span>
			
		</div>

		<div class="para2">
		
		<p>
		Ayurveda has struggled from time to time to show its power of healing naturally. According to the World Health Organization, about 70–80% of the world population relies on nonconventional medicines mainly herbal sources in their healthcare. Ayurvedic treatment is highly effective. 
<br>
Moreover, the comprehensive knowledge on the basic ideologies of Ayurveda is poorly accepted scientifically due to lack of evidence.  As per the research-based facts, Ayurveda can be used wholeheartedly across the globe. 
<br>
<span class="dec"><b>H2 Ayurveda treatments are not limited to the geographical border.</b></span> In India, Kerala leads in offering the Ayurvedic herbs hub where the medicinal plants are grown and the treatment is taken care of.  WHO even pointed out that in barren frozen places like Alaska, people can enjoy <b>Ayurvedic treatment</b> for <b>immunity boosting. </b>
<br>
The world affected by major epidemics like Swine flu, Cholera, Meningitis, Plague, Small Pox, Influenza, and recently <b>Coronavirus (COVID-19)</b> have extensively affected masses. It is because the commoners are lacking in sufficient immunity. 		
<br>
Ayurveda is a great option to combat any virus by building stronger immunity to fight against the diseases. WHO completely supports that fact that “People need to build their immunity stronger to combat a pandemic. It is the best <b>COVID-19 treatment.”</b>
</p>
</div>
 
						  <div class="spacecontent"></div>
		  <div class="spacecontent"></div>
		   <h1 class="text-center"> H1 WHO accepted Ayurveda to be a mindful therapy </h1>
						<div class="custimg my-polygon">
			
			
			<span><img src="<?php echo e(asset('/public/images/butterfly.gif')); ?>"> </span>
			
		</div>

		<div class="para2">
		
		<p>
		Ayurveda has struggled from time to time to show its power of healing naturally. According to the World Health Organization, about 70–80% of the world population relies on nonconventional medicines mainly herbal sources in their healthcare. Ayurvedic treatment is highly effective. 
<br>
Moreover, the comprehensive knowledge on the basic ideologies of Ayurveda is poorly accepted scientifically due to lack of evidence.  As per the research-based facts, Ayurveda can be used wholeheartedly across the globe. 
<br>
<span class="dec"><b>H2 Ayurveda treatments are not limited to the geographical border.</b></span> In India, Kerala leads in offering the Ayurvedic herbs hub where the medicinal plants are grown and the treatment is taken care of.  WHO even pointed out that in barren frozen places like Alaska, people can enjoy <b>Ayurvedic treatment</b> for <b>immunity boosting. </b>
<br>
The world affected by major epidemics like Swine flu, Cholera, Meningitis, Plague, Small Pox, Influenza, and recently <b>Coronavirus (COVID-19)</b> have extensively affected masses. It is because the commoners are lacking in sufficient immunity. 		
<br>
Ayurveda is a great option to combat any virus by building stronger immunity to fight against the diseases. WHO completely supports that fact that “People need to build their immunity stronger to combat a pandemic. It is the best <b>COVID-19 treatment.”</b>
</p>
</div>
						  <div class="spacecontent"></div>
		  <div class="spacecontent"></div>
		   <h1 class="text-center"> H1 WHO recognizes Ayurveda for building immunity worldwide </h1>
							<div class="hexagon">
			
			
			<span><img src="<?php echo e(asset('/public/images/gif1.gif')); ?>" class="l1"> </span>
			
		</div>

		<div class="parashape">
		
		<p>
		Vote of Appreciation towards World Health organization to make an effort of recognizing the finest treatment Ayurveda for building immunity. <b>Ayurveda in its process of progression seems to be caught up during the last several centuries resulting in chronic stagnancy of today.</b>
		<br>
		Western medication is advanced in many cases to provide a solution, but Ayurveda received the recognition which it deserved. It is important to grow and embrace the modernity of Ayurveda which does not mean blind acceptance of Western logic. <b>AYUSH Ministry</b> along with WHO estimated that around 80% of the world's population still trusting in Ayurvedic medicines and its multi-dimensional treatment for their healthy survival of life.  
		<br>
		Be its tropical climate, temperate or polar climate, Ayurveda is the ultimate solution for <b>immunity boosting</b> combating global epidemics or related virus. Time has come to recreate the process of going back to the roots of the medicinal system by combining both healing and curative models from Ayurvedic treatments.
		<br>
		Today, the cost of healthcare is continually rising, and disturbing people's capability to pay for health coverage. The validation to apply for the best Ayurvedic treatments and getting yourself into it is the only way to make a stronger life. 
		<br>
		Exploring Ayurvedic treatments and courses while you’re in a country like India, where Ayurveda is born, will strengthen you from the roots. This will only advance, promote and develop Ayurveda in each of our lives.
		
</p>


		</div>

	<div class="calfunc">
  <div class="firstanimation d-flex">
    <h1 data-animation="fadeInUp" style='display: none'>
      This is Title
    </h1>
  </div>
  <div class="secondanimation d-flex">
    <p data-animation="fadeInUP" style='display: none'>
      This is Description
    </p>
  </div>
  <div class="lastanimation d-flex">
    <p data-animation="fadeInUP" style='display: none'><a href="#">Link</a></p>
  </div>
</div>
	</section>


	  <!----------end of static and dynamic column-------------->
      <div class="heightspace"></div>
    	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->

      <script src="<?php echo e(asset('/public/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin ------------>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->
	  <script>
// With Queue
function animate2(queue) {
  if (queue && queue.length > 0) {
    var elm = queue.shift();

    var animClass = "animated " + $(elm).data('animation');

    $(elm).show().addClass(animClass)
      .on('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
        $(elm).removeClass();
        animate2(queue);
      });
  }
};



$(function() {
  var animationQueue = [
    $('.calfunc').find('.firstanimation h1'),
    $('.calfunc').find('.secondanimation p'),
    $('.calfunc').find('.lastanimation p')
  ];

  animate2(animationQueue);
});
	  </script>
	  <script>
    $(function(){
    $(".dropdown").hover(            
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');              
            },
            function() {
                $('.dropdown-menu', this).stop( true, false ).fadeOut("fast");
                $(this).toggleClass('open');               
            });
    });
	  </script>
      <script type="text/javascript">
	   $('.slider-for').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: true,
  asNavFor: '.slider-nav'
});
	  
	  $('.slider-nav').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  asNavFor: '.slider-for',
  });
         $(document).on('ready', function() {
          $(".regular").slick({
                dots: false,
         	arrows: false,
                slidesToShow: 1,
                slidesToScroll: 1,
         	fade:true,
         	autoplay:true
         
              });
             $(".regularlistbanner").slick({
                dots: false,
         	arrows: true,
                slidesToShow: 3,
                slidesToScroll: 1,
         	speed:500,
         	autoplay:true,
         
              });
         		    $(".regularanimate").slick({
                dots: false,
         	arrows: false,
                slidesToShow: 1,
                slidesToScroll: 1,
         	fade:true,
         	autoplay:true,
         
              });
           			    $(".regularplus").slick({
                dots: false,
         	arrows: false,
                slidesToShow: 4,
                slidesToScroll: 1,
         	autoplay:true,
         
              });
             $(".regularbg").slick({
                dots: false,
         	arrows: false,
                slidesToShow: 4,
                slidesToScroll: 1,
         	autoplay:true,
         
              });
         });
      </script>
   </body>
</html>