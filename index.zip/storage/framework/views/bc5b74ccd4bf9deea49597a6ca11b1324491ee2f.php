<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact Us</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->  
    <link rel="icon" type="image/png" href="<?php echo e(asset('/public/dashboard/images/icons/favicon.ico')); ?>"/>

<!--===============================================================================================-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/dashboard/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/dashboard/fonts/iconic/css/material-design-iconic-font.min.css')); ?>">

<!--===============================================================================================-->
   
     
     
       <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/dashboard/css/main.css')); ?>">
<!--===============================================================================================-->
</head>
<body>
<header class="header_area fixed-top">
<nav class="navbar navbar-expand-lg navbar-light bg-white pl-3 pr-3">
<div class="row">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav ml-auto mt-2 mt-lg-0 text-uppercase">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">HOME<span class="sr-only">(current)</span></a>
      </li>
                       <li class="nav-item dropdown">
                      <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">category <b class="caret"></b></a>
                      <ul class="dropdown-menu text-center">
                        <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">Yoga 101</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">Practice</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">Travel</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/logical')); ?>">Logical</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
                      </ul>
                    </li>
      <li class="nav-item">
        <a class="nav-link" href="#">INSURANCE</a>
      </li>
    </ul>

  </div>
  </div>
</nav>
</header>
    <div class="limiter shadow">
        <div class="container-login100">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-10 col-xm-12 col-sm-12">
                
                <div class="wrap-login100">
                    <form method="POST" action="<?php echo e(url('/contact-request')); ?>" class="login100-form validate-form">
                    <?php echo e(csrf_field()); ?>

                    <span class="login100-form-logo">
                        <i class="zmdi zmdi-landscape"></i>
                    </span>

                    <span class="login100-form-title p-b-34 p-t-27">
                        Contact Us
                    </span>
                    <div class="wrap-input100 validate-input <?php echo e($errors->has('name') ? ' has-error' : ''); ?>" data-validate ="Enter username">
                        <input class="input100" type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Your Name" required="required">
                        <?php if($errors->has('name')): ?>
                                    <span class="focus-input100">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                        <?php endif; ?>
                        <span class="focus-input100" data-placeholder="&#xf207;"></span>
                    </div>

                    <div class="wrap-input100 validate-input <?php echo e($errors->has('email') ? ' has-error' : ''); ?>" data-validate ="Enter email">
                        <input class="input100" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required="required">
                        <?php if($errors->has('email')): ?>
                                    <span class="focus-input100">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                        <?php endif; ?>
                        <span class="focus-input100" data-placeholder="&#xf207;"></span>
                    </div>

                    <div class="wrap-input100 validate-input<?php echo e($errors->has('message') ? ' has-error' : ''); ?>" data-validate="Enter message">
                     <textarea name="message" class="input100" placeholder="Type Your Message" rows="10" required="required"></textarea>
                        
                        <?php if($errors->has('message')): ?>
                                    <span class="focus-input100">
                                        <strong><?php echo e($errors->first('message')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        <span class="focus-input100" data-placeholder="&#xf207;"></span>
                    </div>
                  
                    <div class="container-login100-form-btn">
                        <button type="submit" class="login100-form-btn">
                            Send
                        </button>
                    </div>
                </form>
                </div>
            </div>
                
        </div>
        </div>
    </div>
    

    <div id="dropDownSelect1"></div>
 
<!--===============================================================================================-->
   <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
<!--===============================================================================================-->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<!--===============================================================================================-->


</body>
</html>