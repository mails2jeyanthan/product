<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="robots" content="noindex,nofollow"/>
	<title></title>
	
</head>
<body>
<h1>Hi,</h1>
<div class="row">
	<div class="col-md-12">
		<div class="col-md-6">
			Name :
		</div>
		<div class="col-md-6">
			<?php echo e($na); ?>

		</div>
	</div>
</div>


<div class="row">
	<div class="col-md-12">
		<div class="col-md-6">
			Email :
		</div>
		<div class="col-md-6">
			<?php echo e($em); ?>

		</div>
	</div>
</div>
<p><?php echo e($msg); ?></p>
<p>Email coming from https://www.yogi360blogs.com Contact window.</p>
<p></p>
</body>
</html>