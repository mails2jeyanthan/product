<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/78/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/78/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/78/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">
      <title><?php echo e($Meditations->title); ?></title>
   </head>
   <body class="blog8">
	<section class="blog6whitebandheader">
				<div class="container padding">
	
          
         <nav class="navbar navbar-expand-lg navbar-light p-0 m-0">
            <a class="navbar-brand p-0 m-0" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/78/images/logo-white.png')); ?>" class="blog8logo"></a>
			
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
               <ul class="navbar-nav text-uppercase ml-auto mt-2 mt-lg-0 text-uppercase">
                  <li class="nav-item active">
                     <a class="nav-link" href="finalabt.html" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
					  <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
					  <ul class="dropdown-menu text-center">
						<li><a class="nav-link" href="#">meditation</a></li>
						<li><a class="nav-link" href="#">asana</a></li>
						<li><a class="nav-link" href="#">pranayam</a></li>
						<li><a class="nav-link" href="#">mudra</a></li>
						<li class="divider"></li>
						<li><a class="nav-link" href="#">mystic</a></li>
					  </ul>
					</li>
                  <li class="nav-item dropdown">
					  <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
					  <ul class="dropdown-menu text-center">
						<li><a class="nav-link" href="#">beginner</a></li>
						<li><a class="nav-link" href="#">intermediate</a></li>
						<li><a class="nav-link" href="#">advanced</a></li>
						<li><a class="nav-link" href="#">anatomy</a></li>
					  </ul>
					</li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
					  <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
					  <ul class="dropdown-menu text-center">
						<li><a class="nav-link" href="listing.html#staticDynamic">widespread</a></li>
						<li><a class="nav-link" href="#">ttc</a></li>
						<li><a class="nav-link" href="#">courses</a></li>
						<li><a class="nav-link" href="#">retreats</a></li>
						<li><a class="nav-link" href="#">wellness</a></li>
						<li><a class="nav-link" href="#">trends</a></li>
						<li><a class="nav-link" href="#">studios</a></li>
					  </ul>
					</li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">inspiring</a>
                  </li>
               </ul>
            </div>
         </nav>
   
	  
		 </div>
	</section>
		<div class="container-fluid p-0 mt-5 mb-5">
		 <div class="row">
			<div class="col-lg-6 col-md-12 col-sm-12 pl-5 radiushead">
			<?php echo e($Meditations->title); ?>

			<h5><?php echo e($Meditations->short_desc); ?></h5>
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 radiusimgwrap">
				<img src="<?php echo e(asset('/storage/app/'.$Meditations->image1)); ?>" class="img-fluid w-100 d-block">
			</div>
		 </div>
		</div>
				<div class="container-fluid p-0 mt-5 mb-5">
		 <div class="row">

			<div class="col-lg-8 col-md-12 col-sm-12 radiusbluewrap">
				
			</div>
			<div class="radiuscard col-md-12 col-sm-12 w-100 d-block text-justify">
			<?php echo $Meditations->editor1; ?>

	
			</div>
		 </div>
		</div>
				<div class="container-fluid p-0 mt-5 mb-5">
		 <div class="row">
			<div class="col-lg-6 col-md-12 col-sm-12 pl-5 text-justify radiuspara">
			
			<?php echo $Meditations->editor2; ?>

			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 radiusimgwrap">
				<img src="<?php echo e(asset('/storage/app/'.$Meditations->image2)); ?>" class="img-fluid w-100 d-block">
			</div>
		 </div>
		</div>
				<div class="container-fluid p-0 mt-5 mb-5">
		 <div class="row">

			<div class="col-lg-8 col-md-12 col-sm-12 radiusbluewrap">
				
			</div>
			<div class="radiuscard col-md-12 col-sm-12 w-100 d-block text-justify">
			<?php echo $Meditations->editor3; ?>

	
				</div>
		 </div>
		</div>
						<div class="container-fluid p-0 mt-5 mb-5">
		 <div class="row">
			<div class="col-lg-6 col-md-12 col-sm-12 pl-5 text-justify radiuspara">
			<?php echo $Meditations->editor4; ?>

			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 radiusimgwrap">
				<img src="<?php echo e(asset('/storage/app/'.$Meditations->image3)); ?>" class="img-fluid w-100 d-block">
			</div>
		 </div>
		</div>
				<div class="container-fluid p-0 mt-5 mb-5">
		 <div class="row">

			<div class="col-lg-8 col-md-12 col-sm-12 radiusbluewrap">
				
			</div>
			<div class="radiuscard col-md-12 col-sm-12 w-100 d-block text-justify">
			<?php echo $Meditations->editor5; ?>

			</div>
		 </div>
		</div>
								<div class="container-fluid p-0 mt-5 mb-5">
		 <div class="row">
			<div class="col-lg-6 col-md-12 col-sm-12 pl-5 text-justify radiuspara">
			<?php echo $Meditations->editor6; ?>

			
			</div>
			<div class="col-lg-6 col-md-12 col-sm-12 radiusimgwrap">
				<img src="<?php echo e(asset('/storage/app/'.$Meditations->image4)); ?>" class="img-fluid w-100 d-block">
			</div>
		 </div>
		</div>

			  <footer class="footer-area bgwood">
<div class="container-fluid">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6 class="NonOpaque">OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="https://www.yogi360.com/">Yogi360</a></li>
<li><a href="https://www.yogi360live.com/">Yogi360 Live</a></li>
<li><a href="https://www.yogi360ayurveda.com/">Yogi360 Ayurveda</a></li>
<li><a href="https://www.yogi360retreats.com/">Yogi360 Retreat</a></li>
<li><a href="https://www.yogi360jobs.com">Yogi360 Jobs</a></li>
<li><a href="https://www.yogi360store.com">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/yoga-101')); ?>">Yoga 101 </a></li>
<li><a href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
<li><a href="<?php echo e(url('/logical')); ?>">Logical</a></li>
<li><a href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
<li><a href="<?php echo e(url('/travel')); ?>">Travel</a></li>
<li><a href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
<li><a href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/blog-details-1/1')); ?>">Emotion | Body | Yoga : A connection that you need to know</a></li>
<li><a href="<?php echo e(url('/blog-details-3/1')); ?>">Teach your students by Wisdom and not by Hand</a></li>
<li><a href="<?php echo e(url('/blog-details-4/1')); ?>">Physical Training or Yoga- Which is more important in school?</a></li>
<li><a href="<?php echo e(url('/blog-details-5/1')); ?>">How does a mantra purify emotional lifestyles?</a></li>
<li><a href="<?php echo e(url('/blog-details-6/1')); ?>">Breathing purifies your emotions: Did you know it?</a></li>
<li><a href="<?php echo e(url('/blog-details-7/2')); ?>">Yoga practitioners diet: Are you eating what your body demands?</a></li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/#about')); ?>">About Us</a></li>
<li><a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row justify-content-center pb-3 mt-5">


Copyright © 2020 Yogi360, <br>All rights reserved Powered By Yogi360

</div>

<div class="row pb-5">
<div class="footer-social d-flex mx-auto">
<a href="#"><img src="<?php echo e(asset('/public/78/images/face.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/78/images/insta.png')); ?>"></a>
<a href="#"><img src="<?php echo e(asset('/public/78/images/link.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/78/images/tweet.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/78/images/you.png')); ?>"></i></a>
</div>
</div>
</div>

</footer>
</div>
 <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
      <script src="<?php echo e(asset('/public/78/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin -->
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->
	<script src="<?php echo e(asset('/public/78/js/slider.js')); ?>" type="text/javascript" charset="utf-8"></script>

   </body>
</html>

		
	