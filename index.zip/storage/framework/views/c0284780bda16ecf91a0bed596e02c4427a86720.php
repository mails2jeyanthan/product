<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
    <title>Product</title>
</head>
<body>
<div class="container">
<div class="row">
<div class="col-md-12">
<h2> Form for Update Price in Energy Provider</h2>
    <form action="<?php echo e(url('/api/energy/update')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<input type="hidden" method="PATCH" required="required">
<input type="number" name="id" required="required" placeholder="Enter ID">
<input type="text" name="price" required="required" placeholder="Enter Price in USD">
<button type="Submit">Update</button>
    
</form>
</div>
    
</div>
<div class="row">
    <h2>Energy Providers List</h2>
    <div class="col-md-12">
        <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Product</th>
            <th>Product Variation</th>
            <th>Price</th>
            
        </tr>
        
        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($Product->id); ?></td>
                 <td><?php echo e($Product->prov_name); ?></td>
                  <td><?php echo e($Product->product); ?></td>
                   <td><?php echo e($Product->product_variation); ?></td>
                    <td><?php echo e($Product->price); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    </div>
</div>

</div>
</body>
</html>