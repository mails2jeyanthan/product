<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/456/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/456/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/456/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">
      <title><?php echo e($Foods->title); ?></title>
   </head>
   <body class="blog6">
	<section class="blog6whitebandheader">
				<div class="container padding">
	
          
         <nav class="navbar navbar-expand-lg navbar-light p-0 m-0">
            <a class="navbar-brand p-0 m-0" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/456/images/logo-white.png')); ?>" class="logobg"></a>
			
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul class="navbar-nav text-uppercase mr-auto mt-2 mt-lg-0">
                  <li class="nav-item active">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/yoga-101')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">meditation</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">asana</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">pranayam</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mudra</a></li>
                  <li class="divider"></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mystic</a></li>
                 </ul>
                </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/practice')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">beginner</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">intermediate</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">advanced</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">anatomy</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/lifestyle')); ?>">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/travel')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">widespread</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">ttc</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">courses</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">retreats</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">wellness</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">trends</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">studios</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/logical')); ?>">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/inspiring')); ?>">inspiring</a>
                  </li>
              </ul>
               
            </div>
         </nav>
   
	  <!-- Main -->
		 </div><!-----------------end of container------------------>
	</section>
	<div class="container-fluid p-0 m-0 blog6banner">
		<div class="col-lg-4 col-md-4 offset-lg-1 offset-md-1 col-sm-4 offset-sm-1 col-xs-5 offset-xs-1 blog6banhead sticky position-absolute">
			<div class="bggreen">
			<?php echo e($Foods->title); ?>

			</div>
		</div>
	</div>
		<div class="container-fluid p-0 m-0">
		<div class="row no-gutters">
		<div class="col-lg-4 col-md-4 offset-lg-1 offset-md-1 col-sm-12 col-xs-12 blog6parahead">
		<img src="<?php echo e(asset('/storage/app/'.$Foods->image2)); ?>" class="img-fluid w-100 h-100 d-block">
		</div>
		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 blog6textpara text-justify">
		<?php echo $Foods->editor1; ?>


		</div>
		</div>
				<div class="row no-gutters">
	
		<div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-sm-12 blog6greenpara text-justify">
		<?php echo $Foods->editor2; ?>



		</div>
		</div>
				<div class="row no-gutters">
		<div class="col-lg-6 col-md-6 offset-lg-1 offset-md-1 col-sm-12 col-xs-12 blog6pic">
		<img src="<?php echo e(asset('/storage/app/'.$Foods->image3)); ?>" class="img-fluid w-100 h-100 d-block">
		</div>

		</div>
				<div class="row no-gutters">
	
		<div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-sm-12 blog6greenpara text-justify">
		<?php echo $Foods->editor3; ?>

		</div>
		</div>
				<div class="row no-gutters">

		<div class="col-lg-6 col-md-6 offset-lg-1 offset-md-1 col-sm-12 col-xs-12 blog6textpara text-justify">
			<?php echo $Foods->editor4; ?>


		</div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 blog6parahead">
		<img src="<?php echo e(asset('/storage/app/'.$Foods->image4)); ?>" class="img-fluid w-100 h-100 d-block">
		</div>
		</div>
				<div class="row no-gutters">
	
		<div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-sm-12 blog6greenpara text-justify">
		<?php echo $Foods->editor5; ?>

		</div>
		</div>
						<div class="row no-gutters">
		<div class="col-lg-6 col-md-6 offset-lg-1 offset-md-1 col-sm-12 col-xs-12 blog6pic">
		<img src="<?php echo e(asset('/storage/app/'.$Foods->image5)); ?>" class="img-fluid w-100 h-100 d-block">
		</div>

		</div>
				<div class="row no-gutters">
	
		<div class="col-lg-10 offset-lg-1 col-md-10 offset-md-1 col-sm-12 blog6greenpara text-justify">
		<?php echo $Foods->editor6; ?>

		</div>
		</div>
	</div>

			  <footer class="footer-area bgwood">
<div class="container-fluid">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6 class="NonOpaque">OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="https://www.yogi360.com/">Yogi360</a></li>
<li><a href="https://www.yogi360live.com/">Yogi360 Live</a></li>
<li><a href="https://www.yogi360ayurveda.com/">Yogi360 Ayurveda</a></li>
<li><a href="https://www.yogi360retreats.com/">Yogi360 Retreat</a></li>
<li><a href="https://www.yogi360jobs.com">Yogi360 Jobs</a></li>
<li><a href="https://www.yogi360store.com">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/yoga-101')); ?>">Yoga 101 </a></li>
<li><a href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
<li><a href="<?php echo e(url('/logical')); ?>">Logical</a></li>
<li><a href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
<li><a href="<?php echo e(url('/travel')); ?>">Travel</a></li>
<li><a href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
<li><a href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/blog-details-1/1')); ?>">Emotion | Body | Yoga : A connection that you need to know</a></li>
<li><a href="<?php echo e(url('/blog-details-3/1')); ?>">Teach your students by Wisdom and not by Hand</a></li>
<li><a href="<?php echo e(url('/blog-details-4/1')); ?>">Physical Training or Yoga- Which is more important in school?</a></li>
<li><a href="<?php echo e(url('/blog-details-5/1')); ?>">How does a mantra purify emotional lifestyles?</a></li>
<li><a href="<?php echo e(url('/blog-details-6/1')); ?>">Breathing purifies your emotions: Did you know it?</a></li>
<li><a href="<?php echo e(url('/blog-details-7/2')); ?>">Yoga practitioners diet: Are you eating what your body demands?</a></li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="#">About Us</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row justify-content-center pb-3 mt-5">


Copyright © 2020 Yogi360, <br>All rights reserved Powered By Yogi360

</div>

<div class="row pb-5">
<div class="footer-social d-flex mx-auto">
<a href="#"><img src="<?php echo e(asset('/public/456/images/face.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/456/images/insta.png')); ?>"></a>
<a href="#"><img src="<?php echo e(asset('/public/456/images/link.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/456/images/tweet.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/456/images/you.png')); ?>"></i></a>
</div>
</div>
</div>

</footer>
</div>
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
      <script src="<?php echo e(asset('/public/456/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin -->
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->
	<script src="<?php echo e(asset('/public/456/js/slider.js')); ?>" type="text/javascript" charset="utf-8"></script>

   </body>
</html>

		
	