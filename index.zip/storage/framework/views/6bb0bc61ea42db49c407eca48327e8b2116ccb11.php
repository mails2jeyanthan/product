<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">

      <title>Privacy Policy</title>


</head>
<body onload="document.body.style.opacity='1'" class="grayshade">
      <header class="fixed-top">
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>" class="innerlogo"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
               <ul class="navbar-nav text-uppercase mr-auto mt-2 mt-lg-0">
                  <li class="nav-item active">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/yoga-101')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">meditation</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">asana</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">pranayam</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mudra</a></li>
                  <li class="divider"></li>
                  <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">mystic</a></li>
                 </ul>
               </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/practice')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">beginner</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">intermediate</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">advanced</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">anatomy</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/lifestyle')); ?>">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
                 <a href="<?php echo e(url('/travel')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
                 <ul class="dropdown-menu text-center">
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">widespread</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">ttc</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">courses</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">retreats</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">wellness</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">trends</a></li>
                  <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">studios</a></li>
                 </ul>
               </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/logical')); ?>">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/inspiring')); ?>">inspiring</a>
                  </li>
               </ul>
               
            </div>
         </nav>
      </header>
        
     
<section class="blogtextwrap m-0">
<div class="marg container-fluid py-5 bg-white insetpadding shadow">
<div class="row align-items-center">
<div class="col-md-12 col-lg-12" data-aos="fade-up">
<div class="paracontent">
<h1 class="text-center">Privacy Policy</h1>
     <p> Yogi360 Blogs, (“us”, “we”, or “our”) operates the https://yogi360blogs.com/ website (the “Service”).
This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. We use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from //mailto:https://www.yogi360blogs.com/</p>

<h2>COLLECTION OF INFORMATION</h2>
<h3>Information You Provide to Us</h3>
<h4>Account Information</h4>
<p>If you wish to use the Services, such as to create or post content, or to post your own content to Partners’ content, or if you wish to receive updates or newsletters from us or from our Partners, you will be required to create a account with us. When you create an account or use our Services, we ask you to provide certain personally identifiable information such as your first and last name, email address, telephone number, address, and payment card information (collectively, “Personally Identifiable Information”).</p> 

<h3>Other Information</h3>
<p>We also collect any other information you provide directly to us. For example, we collect information when you participate in any interactive features of the Services, fill out a form, participate in a contest or promotion, make a purchase, apply for a job, communicate with us via third party social media sites, request customer support, or otherwise communicate with us.</p>

<h3>Automatically Collected Data</h3>
<p>When you access or use our Services, we automatically collect certain technical information, including:</p>
<ul>
  <li>Log and Usage Information: We collect information related to your access to and use of the Services, including the type of browser you use, app version, access times, pages viewed, your IP address, and the page you visited before navigating to our Services.</li>
  <li>Device Information: We collect information about the computer or mobile device you use to access our Services, including the hardware model, operating system and version, unique device identifiers, and mobile network information.</li>
  <li>Information Collected by Cookies and Similar Tracking Technologies: We (and our service providers and Partners) use different technologies to collect information, including cookies and web beacons. Cookies are small data files stored on your hard drive or in device memory that help us improve our Services and your experience, see which areas and features of our Services are popular, and count visits. Web beacons (also known as “pixel tags” or “clear GIFs”) are electronic images that may be used in our Services or emails and help deliver cookies, count visits, and understand usage and campaign effectiveness. For more information about cookies and how to disable them, see Your Choices below.</li>
</ul>

<h3>Information We Collect from Other Sources</h3>
<p>We may also obtain information about you from other sources. For example, we may collect information about you from third parties, including but not limited to identity verification services, credit bureaus, mailing list providers, and publicly available sources. Additionally, if you create or log into your account through a social media site or third-party service (like Facebook or Google), we will have access to certain information from that service, such as your name, email address, and profile picture, in accordance with the authorization procedures determined by such social media site or third-party service.</p>

<h3>USE OF INFORMATION</h3>
<p>We use the information we collect to provide our Services and to customize your experience with the Services, including to show content and advertising that we think is likely to be of interest to you. We also use the information we collect to:</p>
<ul>
  <li>Communicate with you about products, services, and events offered by us and others, and provide news and information we think will be of interest to you;</li>
  <li>Monitor and analyze trends, usage, and activities in connection with our Services;</li>
  <li>Detect, investigate and prevent fraudulent transactions and other illegal activities and protect the rights and property of Yogi360;</li>
  <li>Facilitate contests, sweepstakes, and promotions and process and deliver entries and rewards; and</li>
  <li>Carry out any other purpose described to you at the time the information was collected.</li>
</ul>
<h3>SHARING OF INFORMATION</h3>
<p>When you subscribe to, you will be providing your username and email address to us as well and we may use such information to contact you and otherwise use and disclose your personal information in accordance with its privacy policy. We will not share your identifying information (such as your name, email address, address or phone number) with Partners in our coalition except where you decide to provide that information to the Partner, ask us to share it with them, or consent to our sharing it with them.</p>
<p>To allow Partners to earn advertising from their content, we share identifiers that do not identify you personally but may identify your browser or device with Partners and advertising partners as described in the “Advertising and Analytics Services Provided by Others” section below. Our Partners may also collect their own identifiers for these purposes.</p>
<p>We may also share the information we collect as follows:</p>
<ul>
  <li>With vendors, service providers, and consultants that perform services for us, including email providers, IT service providers, and web hosting providers;</li>
  <li>In response to a request for information if we believe disclosure is in accordance with, or required by, any applicable law or legal process, including lawful requests by public authorities to meet national security or law enforcement requirements;</li>
  <li>If we believe your actions are inconsistent with our user agreements or policies, if we believe you have violated the law, or to protect the rights, property, and safety of Yogi360, Partners, or others;</li>
  <li>In connection with, or during negotiations of, any merger, sale of company assets, financing or acquisition of all or a portion of our business by another company;</li>
  <li>Between and among our current and future parents, affiliates, subsidiaries, and other companies under common control and ownership, including but not limited to Say Media; and</li>
  <li>With your consent or at your direction.
We may also share aggregated information that cannot reasonably be used to identify you.</li>
</ul>
<h3>Security Of Data</h3>
<p>The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.</p>


<h3>Analytics</h3>
<p>We may use third-party Service Providers to monitor and analyze the use of our Service.</p>
<h3>Google Analytics</h3>
<p>Google Analytics is a web analytics service offered by Google that tracks and reports website traffic. Google uses the data collected to track and monitor the use of our Service. This data is shared with other Google services. Google may use the collected data to contextualize and personalize the ads of its own advertising network. You can opt-out of having made your activity on the Service available to Google Analytics by installing the Google Analytics opt-out browser add-on. The add-on prevents the Google Analytics JavaScript (ga.js, analytics.js, and dc.js) from sharing information with Google Analytics about visits activity. For more information on the privacy practices of Google, please visit the Google Privacy & Terms web page: https://policies.google.com/privacy?hl=en</p>


<h3>YOUR CHOICES</h3>
<h4>Account Information</h4>
<p>You may update certain account information you provide to us at any time by logging into your account*.* If you wish to delete or deactivate your account, please email us, but please note that we may retain certain information as required by law or for legitimate business purposes. We may also retain cached or archived copies of information about you for a certain period of time.</p>
<h3>Cookies</h3>
<p>Most web browsers are set to accept cookies by default. If you prefer, you can usually choose to set your browser to remove or reject browser cookies. Please note that if you choose to remove or reject cookies, this could affect the availability and functionality of our Services.
Promotional Communications</p>
<p>You may opt out of receiving promotional emails from us by following the instructions in those emails. If you opt out, we may still send you non-promotional emails, such as those about your account or our ongoing business relations.</p>
<p>If you wish to opt out of receiving promotional communications from a Partner, you may do so by following the instructions provided by the Partner.</p>


<h3>Data Subject Requests</h3>
<p>You have the right to access personal data we hold about you and to ask that your personal data be corrected, erased, or transferred. You may also have the right to object to, or request that we restrict, certain processing. If you would like to exercise any of these rights you may contact us as indicated below.</p>
<h3>Data Retention</h3>
<p>We store the information we collect on you for as long as is necessary for the purpose(s) for which we originally collected it, or for other legitimate business purposes, including to meet our legal, regulatory, or other compliance obligations.</p>

<h3>Children’s Privacy</h3>
<p>Our Service does not address anyone under the age of 18 (“Children”). We do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.</p>
<h3>Changes To This Privacy Policy</h3>
<p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. We will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the “effective date” at the top of this Privacy Policy. You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.</p>
<h3>Contact Us</h3>
<p>If you have any questions about this Privacy Policy, please contact us via email at contact@yogi360blogs.com</p>

    
</div>

</div>
</div>
</div>

</section>
<footer class="footer-area">
<div class="container">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="https://www.yogi360.com/">Yogi360</a></li>
<li><a href="https://www.yogi360live.com/">Yogi360 Live</a></li>
<li><a href="https://www.yogi360ayurveda.com/">Yogi360 Ayurveda</a></li>
<li><a href="https://www.yogi360retreats.com/">Yogi360 Retreat</a></li>
<li><a href="https://www.yogi360jobs.com">Yogi360 Jobs</a></li>
<li><a href="https://www.yogi360store.com">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/yoga-101')); ?>">Yoga 101 </a></li>
<li><a href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
<li><a href="<?php echo e(url('/logical')); ?>">Logical</a></li>
<li><a href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
<li><a href="<?php echo e(url('/travel')); ?>">Travel</a></li>
<li><a href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
<li><a href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/blog-details-1/1')); ?>">Emotion | Body | Yoga : A connection that you need to know</a></li>
<li><a href="<?php echo e(url('/blog-details-3/1')); ?>">Teach your students by Wisdom and not by Hand</a></li>
<li><a href="<?php echo e(url('/blog-details-4/1')); ?>">Physical Training or Yoga- Which is more important in school?</a></li>
<li><a href="<?php echo e(url('/blog-details-5/1')); ?>">How does a mantra purify emotional lifestyles?</a></li>
<li><a href="<?php echo e(url('/blog-details-6/1')); ?>">Breathing purifies your emotions: Did you know it?</a></li>
<li><a href="<?php echo e(url('/blog-details-7/2')); ?>">Yoga practitioners diet: Are you eating what your body demands?</a></li>
</ul>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/#about')); ?>">About Us</a></li>
<li><a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
<li><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li>
<li><a href="#">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row">

<p class="footer-text mx-auto">
Copyright © 2020 Yogi360, All rights reserved Powered By<a href="https://yogicconnection.com" target="_blank">Yogi360</a>
</p>
</div>
<div class="row pb-3">
<div class="footer-social d-flex mx-auto">
<a href="#"><img src="<?php echo e(asset('/public/images/face.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/insta.png')); ?>"></a>
<a href="#"><img src="<?php echo e(asset('/public/images/link.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/tweet.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/you.png')); ?>"></i></a>
</div>
</div>
</div>

</footer>

     <!---end of static and dynamic column-->
      <div class="heightspace"></div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->

      <script src="<?php echo e(asset('/public/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin -->
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->

   </body>
</html>