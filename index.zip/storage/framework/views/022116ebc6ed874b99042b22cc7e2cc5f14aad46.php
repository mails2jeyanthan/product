<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/css/style.css')); ?>">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick-theme.css')); ?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
      <link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">
      <title>Yoga Approved</title>
   </head>
   <body>
      <header class="fixed-top">
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>" style="width:53%;"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
               <ul class="navbar-nav text-uppercase mr-auto mt-2 mt-lg-0 text-uppercase">
                  <li class="nav-item active">
                     <a class="nav-link" href="<?php echo e(url('/')); ?>" target="_blank">HOME<span class="sr-only">(current)</span></a>
                  </li>
                  <li class="nav-item dropdown">
            <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">yoga 101 <b class="caret"></b></a>
            <ul class="dropdown-menu text-center">
            <li><a class="nav-link" href="#">meditation</a></li>
            <li><a class="nav-link" href="#">asana</a></li>
            <li><a class="nav-link" href="#">pranayam</a></li>
            <li><a class="nav-link" href="#">mudra</a></li>
            <li class="divider"></li>
            <li><a class="nav-link" href="#">mystic</a></li>
            </ul>
          </li>
                  <li class="nav-item dropdown">
            <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">practice <b class="caret"></b></a>
            <ul class="dropdown-menu text-center">
            <li><a class="nav-link" href="#">beginner</a></li>
            <li><a class="nav-link" href="#">intermediate</a></li>
            <li><a class="nav-link" href="#">advanced</a></li>
            <li><a class="nav-link" href="#">anatomy</a></li>
            </ul>
          </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">lifestyle</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a>
                  </li>
                  <li class="nav-item dropdown">
            <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">travel <b class="caret"></b></a>
            <ul class="dropdown-menu text-center">
            <li><a class="nav-link" href="listing.html#staticDynamic">widespread</a></li>
            <li><a class="nav-link" href="#">ttc</a></li>
            <li><a class="nav-link" href="#">courses</a></li>
            <li><a class="nav-link" href="#">retreats</a></li>
            <li><a class="nav-link" href="#">wellness</a></li>
            <li><a class="nav-link" href="#">trends</a></li>
            <li><a class="nav-link" href="#">studios</a></li>
            </ul>
          </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">VIRAL</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">logical</a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link" href="#">inspiring</a>
                  </li>
               </ul>
               <form class="form-inline my-2 my-lg-0">
                  <div class="search__wrapper">
                     <input type="text" name="" placeholder="Search for..." class="search__field">
                     <button type="submit" class="fa fa-search search__icon"></button>
                  </div>
               </form>
            </div>
         </nav>
      </header>
      <section class="banner-slide-listing p-0">
         <div class="container-fluid p-0">
      <div class="row no-gutters">
            <div class="col-lg-4 col-md-12 col-sm-12 liststatic">
               <div class="text-inner">
                  <div class="desc">
                     <h4>Welcome to the world of Yogi360!</h4>
           <div class="spacecontent"></div>
                     <p class="text-justify">You are going to explore what you know already but have forgotten. Our prime intention is to make you familiar with your true nature. Come, let's explore more about yourself... <a href="https://yogi360.com/"></a></p>
                  </div>
               </div>
            </div>
            <div class="col-lg-8 col-md-12 col-sm-12 regularlistbanner">
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l1.png')); ?>"></a>
               
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l2.png')); ?>" alt=""></a>
                 
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l3.png')); ?>" alt=""></a>
                 
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l4.png')); ?>" alt=""></a>

                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l5.png')); ?>" alt=""></a>
                 
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
               <div class="listbanner text-center imgtilt">
                  <a href="#"><img class="img-fluid w-100" src="<?php echo e(asset('/public/images/l6.png')); ?>" alt=""></a>
                
                  <h4>Subscribe
                     <br> our Page
                  </h4>
               </div>
            </div>
         </div>
         <!---row-->
         </div><!---container-fluid -->
      </section>
      <!---end of listingsection -->
    
    <div class="clear"></div>
<div id="staticDynamic p-0">
    <div class="container-fluid p-0">
      <div class="row no-gutters">
        <div class="col lg-12 col-md-12 col-sm-12">
        <main role="main" class="probootstrap-main">
<div class="row no-gutters">
<?php $__currentLoopData = $Posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-4 col-sm-12">

<div class="card shadow">
  <span class="imgzoom p-0 m-0"><img class="card-img-top listimg1" src="<?php echo e(asset('/public/images/i3682.png')); ?>" alt="Card image cap"></span>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($Post->title); ?></h5>
    <p class="card-text">Lorem ipsum Sed eiusmod esse aliqua sed incididunt aliqua incididunt mollit id et sit proident dolor nulla sed commodo est ad minim elit reprehenderit nisi officia aute incididunt velit sint in aliqua...</p>
    <div class="metatag">
<span class="meta-links">
<a href="#">READ MORE </a>
</span>
</div>
  </div>
</div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!---end of col3-->



</div><!---end of row-->
<div class="container-fluid d-md-none">
<div class="row">
<div class="col-md-12">
<ul class="list-unstyled d-flex probootstrap-aside-social">
<li><a href="#" class="p-2"><span class="icon-twitter"></span></a></li>
<li><a href="#" class="p-2"><span class="icon-instagram"></span></a></li>
<li><a href="#" class="p-2"><span class="icon-dribbble"></span></a></li>
</ul>
<p>&copy; 2017 <a href="https://uicookies.com/" target="_blank">uiCookies:Aside</a>. <br> All Rights Reserved. Designed by <a href="https://uicookies.com/" target="_blank">uicookies.com</a></p>
</div>
</div>
</div>
</main>
        </div>
      </div><!---end of row -->
    
    </div>
</div>

    <!---end of static and dynamic column-->
      <div class="heightspace"></div>
      <footer class="footer-area">
         <div class="container">
            <div class="row footer-top">
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <div class="single-footer-widget">
                     <h6>OUR SERVICES</h6>
                     <div class="row">
                        <ul class="col footer-nav">
                           <li><a href="#">Yogi360</a></li>
                           <li><a href="#">Yogi360 Live</a></li>
                           <li><a href="#">Yogi360 Ayurveda</a></li>
                           <li><a href="#">Yogi360 Retreat</a></li>
                           <li><a href="#">Yogi360 Jobs</a></li>
                           <li><a href="#">Yogi360 Stores</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-lg-3 col-md-6 col-sm-6">
                  <div class="single-footer-widget">
                     <h6>TOP CATEGORIES</h6>
                     <div class="row">
                        <ul class="col footer-nav">
                           <li><a href="#">Yoga 101 </a></li>
                           <li><a href="#">Ayurveda</a></li>
                           <li><a href="#">Logical</a></li>
                           <li><a href="#">Viral</a></li>
                           <li><a href="#">Travel</a></li>
                           <li><a href="#">Awakening</a></li>
                           <li><a href="#">Yogis</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4  col-md-6 col-sm-6">
                  <div class="single-footer-widget">
                     <h6>POPULAR BLOGS</h6>
                     <div class="row">
                        <p class="text-left">Mantra is not Religion<br>
                           Six steps of doing asana meditatively<br>
                           The purpose and utility of asanas in Hathayoga<br>
                           What is Ayurveda and how does it help Yoga<br>
                           What is real health in Yogic science for the Yogi<br>
                           Disciplines of yoga teachers and students
                        </p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-2 col-md-6 col-sm-6">
                  <div class="single-footer-widget">
                     <h6>YOGI 360 BLOGS</h6>
                     <div class="row">
                        <ul class="col footer-nav">
                           <li><a href="#">About Us</a></li>
                           <li><a href="#">Contact Us</a></li>
                           <li><a href="#">Privacy Policy</a></li>
                           <li><a href="#">Terms & Condition</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="container-fluid p-0 text-center">
            <div class="row">
               <p class="footer-text mx-auto">
                  Copyright © 2019 Yogi360, All rights reserved Powered By<a href="https://yogicconnection.com" target="_blank">Yogi360</a>
               </p>
            </div>
            <div class="row">
               <div class="footer-social d-flex mx-auto">
                  <a href="#"><i class="fa fa-facebook"></i></a>
                  <a href="#"><i class="fa fa-instagram"></i></a>
                  <a href="#"><i class="fa fa-linkedin"></i></a>
                  <a href="#"><i class="fa fa-twitter"></i></a>
                  <a href="#"><i class="fa fa-youtube"></i></a>
               </div>
            </div>
         </div>
      </footer>
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
      <script src="<?php echo e(asset('/public/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
      <!--- sleek plugin -->
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
      <!-- Optional JavaScript -->
    <script>
    $(function(){
    $(".dropdown").hover(            
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');              
            },
            function() {
                $('.dropdown-menu', this).stop( true, false ).fadeOut("fast");
                $(this).toggleClass('open');               
            });
    });
    </script>
      <script type="text/javascript">
         $(document).on('ready', function() {
          $(".regular").slick({
                dots: false,
          arrows: false,
                slidesToShow: 1,
                slidesToScroll: 1,
          autoplay:true
      
         
              });
             $(".regularlistbanner").slick({
                dots: false,
          arrows: true,
                slidesToShow: 3,
                slidesToScroll: 1,
              infinite: true,
  cssEase: 'linear',
  variableWidth: true,
  variableHeight: true,
          speed:500,
          autoplay:true,
         
              });
                $(".regularanimate").slick({
                dots: false,
          arrows: false,
                slidesToShow: 1,
                slidesToScroll: 1,
          fade:true,
          autoplay:true,
         
              });
                    $(".regularplus").slick({
                dots: false,
          arrows: false,
                slidesToShow: 4,
                slidesToScroll: 1,
          autoplay:true,
         
              });
             $(".regularbg").slick({
                dots: false,
          arrows: false,
                slidesToShow: 4,
                slidesToScroll: 1,
          autoplay:true,
         
              });
         });
      </script>
   </body>
</html>