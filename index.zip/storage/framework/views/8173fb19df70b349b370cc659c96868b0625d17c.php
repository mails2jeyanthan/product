<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Welcome To | ADMIN DASHBOARD</title>
    <!-- Favicon-->
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="<?php echo e(asset('/public/dashboard/plugins/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="<?php echo e(asset('/public/dashboard/plugins/node-waves/waves.css')); ?>" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="<?php echo e(asset('/public/dashboard/plugins/animate-css/animate.css')); ?>" rel="stylesheet" />

    <!-- Morris Chart Css-->
    <link href="plugins/morrisjs/morris.css') }}" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="<?php echo e(asset('/public/dashboard/css/dashstyle.css')); ?>" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="<?php echo e(asset('/public/dashboard/css/themes/all-themes.css')); ?>" rel="stylesheet" />
</head>

<body class="theme-red">
    <?php echo $__env->make('include.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD</h2>
            </div>

            <!-- Widgets -->
            <div class="row clearfix">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">playlist_add_check</i>
                        </div>
                        <div class="content">
                            <div class="text">SEO STATUS</div>
                            <div class="number count-to" data-from="0" data-to="125" data-speed="15" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">help</i>
                        </div>
                        <div class="content">
                            <div class="text">POST PUBLISHED</div>
                            <div class="number count-to" data-from="0" data-to="257" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">forum</i>
                        </div>
                        <div class="content">
                            <div class="text">NEW POST</div>
                            <div class="number count-to" data-from="0" data-to="243" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">person_add</i>
                        </div>
                        <div class="content">
                            <div class="text">TOTAL COUNT</div>
                            <div class="number count-to" data-from="0" data-to="1225" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
            </div>

           
            <div class="row clearfix">
            <div class="row clearfix">
                <!-- Task Info -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 1</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            
                                            <td><?php echo e($Post->title); ?></td>
                                            <td><?php echo e($Post->category); ?></td>
                                            
                                            <td><?php echo e($Post->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-1/'.$Post->pst_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-1/'.$Post->pst_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-1/'.$Post->pst_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal1<?php echo e($Post->pst_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal1<?php echo e($Post->pst_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-1/'.$Post->pst_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 2</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Emotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Emotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($Emotion->title); ?></td>
                                            <td><?php echo e($Emotion->category); ?></td>
                                            
                                            <td><?php echo e($Emotion->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-2/'.$Emotion->emt_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-3/'.$Emotion->emt_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-2/'.$Emotion->emt_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal2<?php echo e($Emotion->emt_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Emotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Emotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal2<?php echo e($Emotion->emt_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-2/'.$Emotion->emt_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 3</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($Title->title); ?></td>
                                            <td><?php echo e($Title->category); ?></td>
                                            
                                            <td><?php echo e($Title->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-3/'.$Title->tt_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-4/'.$Title->tt_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-3/'.$Title->tt_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal3<?php echo e($Title->tt_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal3<?php echo e($Title->tt_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-3/'.$Title->tt_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 4</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($Blog->title); ?></td>
                                            <td><?php echo e($Blog->category); ?></td>
                                            
                                            <td><?php echo e($Blog->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-4/'.$Blog->bg_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-5/'.$Blog->bg_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-4/'.$Blog->bg_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal4<?php echo e($Blog->bg_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal4<?php echo e($Blog->bg_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-4/'.$Blog->bg_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 5</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Breathings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Breathing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($Breathing->title); ?></td>
                                            <td><?php echo e($Breathing->category); ?></td>
                                            
                                            <td><?php echo e($Breathing->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-5/'.$Breathing->br_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-6/'.$Breathing->br_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-5/'.$Breathing->br_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal5<?php echo e($Breathing->br_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Breathings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Breathing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal5<?php echo e($Breathing->br_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-5/'.$Breathing->br_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 6</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($Food->title); ?></td>
                                            <td><?php echo e($Food->category); ?></td>
                                            
                                            <td><?php echo e($Food->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-6/'.$Food->fd_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-7/'.$Food->fd_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-6/'.$Food->fd_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal6<?php echo e($Food->fd_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal6<?php echo e($Food->fd_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-6/'.$Food->fd_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 7</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Masters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($Master->title); ?></td>
                                            <td><?php echo e($Master->category); ?></td>
                                            
                                            <td><?php echo e($Master->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-7/'.$Master->ms_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-8/'.$Master->ms_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-7/'.$Master->ms_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal7<?php echo e($Master->ms_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Masters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Master): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal7<?php echo e($Master->ms_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-7/'.$Master->ms_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>LIST OF MODEL 8</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Products</a></li>
                                        <li><a href="javascript:void(0);">Product Category</a></li>
                                        <li><a href="javascript:void(0);">Product Tags</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                             <th>Title</th>
                                            <th>Status</th>
                                            <th>Category</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $Meditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Meditation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($Meditation->title); ?></td>
                                            <td><?php echo e($Meditation->category); ?></td>
                                            
                                            <td><?php echo e($Meditation->status); ?></td>
                                            <td>
                                               
                                              <a class="iconred" href="<?php echo e(url('/delete-8/'.$Meditation->md_id)); ?>"><i class="material-icons dp48 iconeffect">delete_forever</i></a>
                                              <a class="icongreen" href="<?php echo e(url('/blog-details-9/'.$Meditation->md_id)); ?>" target="_blank"><i class="material-icons dp48 iconeffect">visibility</i></a>
                                              <a class="iconblue" href="<?php echo e(url('/edit-post-8/'.$Meditation->md_id)); ?>"><i class="material-icons dp48 iconeffect">edit</i></a>
                                              <a class="iconorange" data-toggle="modal" href="#myModal8<?php echo e($Meditation->md_id); ?>"><i class="material-icons dp48 iconeffect">publish</i></a>
                                            </td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <?php $__currentLoopData = $Meditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Meditation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="modal" id="myModal8<?php echo e($Meditation->md_id); ?>">
                                           <div class="modal-dialog">
                                             <div class="modal-content">
      
                                               <!-- Modal Header -->
                                               <div class="modal-header">
                                                 <h4 class="modal-title">Publish Post</h4>
                                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                                               </div>
        
                                               <!-- Modal body -->
                                               <div class="modal-body">
                                                 <form action="<?php echo e(url('/post-publish-8/'.$Meditation->md_id)); ?>" method="POST">
                                                 <?php echo e(csrf_field()); ?>

                                                     <div class="row">
                                                         <div class="col-6">
                                                             <label class="form-control">Select Status</label>
                                                         </div>
                                                         <div class="col-6">
                                                             <select name="status" class="form-control" required="required">
                                                                 <option value="Approved">Approved</option>
                                                                 <option value="Waiting">Waiting</option>
                                                                 <option value="Rejected">Rejected</option>
                                                             </select>
                                                         </div>
                                                     </div>
                                                     
                                                     <!-- Modal footer -->
                                                     <div class="modal-footer">
                                                     <button type="Submit" class="btn btn-primar">Submit</button>
                                                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                     </div>

                                                 </form>
                                               </div>
        
                                               
        
                                             </div>
                                           </div>
                                        </div>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </tbody>
                                </table>
                                    
                            </div>
                        </div>
                    </div>
                </div>

                <!-- #END# Task Info -->
               

                
            </div>
        </div>
    </section>
    <!-- Jquery Core Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/jquery/jquery.min.js')); ?>"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/bootstrap/js/bootstrap.js')); ?>"></script>



    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/jquery-slimscroll/jquery.slimscroll.js')); ?>"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/node-waves/waves.js')); ?>"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo e(asset('/public/dashboard/plugins/jquery-countto/jquery.countTo.js')); ?>"></script>



    <!-- Custom Js -->
    <script src="<?php echo e(asset('/public/dashboard/js/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('/public/dashboard/js/pages/index.js')); ?>"></script>

</body>

</html>
