<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/css/style.css')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick-theme.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
<link href="https://fonts.googleapis.com/css2?family=Parisienne&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">

    
    <title>Yoga Approved</title>

  </head>
  <body>
<header class="header_area fixed-top">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav ml-auto mt-2 mt-lg-0 text-uppercase">
      <li class="nav-item active">
        <a class="nav-link" href="#">HOME<span class="sr-only">(current)</span></a>
      </li>
                       <li class="nav-item dropdown">
                      <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">category <b class="caret"></b></a>
                      <ul class="dropdown-menu text-center">
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">yoga 101</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">practice</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">lifestyle</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">ayurveda</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">travel</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">viral</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">logical</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">inspiring</a></li>
                      </ul>
                    </li>
      <li class="nav-item">
        <a class="nav-link" href="#">INSPIRING</a>
      </li>
    </ul>
<form class="form-inline my-2 my-lg-0">
  <div class="search__wrapper">
    <input type="text" name="" placeholder="Search for..." class="search__field">
    <button type="submit" class="fa fa-search search__icon"></button>
  </div>
</form>
  </div>
</nav>
</header>


<div class="regular">

<div class="container-fluid p-0 homeimg2">
    <div class="row">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 absoluteslide">
        
            
<div class="blog_text_slider">
                                <div class="blog_text">
                                    <div class="vr"><span class="homeimgbg2">Yogastra<br>Magic</span></div>                                 
                                    <div class="blog-meta bottom d-flex justify-content-between align-items-center flex-wrap">
                                        <div class="meta">
                                            <span class="icon fa fa-calendar"></span> March 14, 2018
                                            <span class="icon fa fa-comments"></span> 05
                                        </div>
                                        <div>
                                            <a class="read_more" href="#">Read More</a>
                                        </div>
                                    </div>
                                    </div>
                                    </div>
        </div>
    </div>
</div>

<div class="container-fluid p-0 homeimg4">
    <div class="row">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 absoluteslide">
        
            
<div class="blog_text_slider">
                                <div class="blog_text">
                                    <div class="vr"><span class="homeimgbg4">Moment<br>Blessed</span></div>                                 
                                    <div class="blog-meta bottom d-flex justify-content-between align-items-center flex-wrap">
                                        <div class="meta">
                                            <span class="icon fa fa-calendar"></span> March 14, 2018
                                            <span class="icon fa fa-comments"></span> 05
                                        </div>
                                        <div>
                                            <a class="read_more" href="#">Read More</a>
                                        </div>
                                    </div>
                                    </div>
                                    </div>
        </div>
    </div>
</div>
<div class="container-fluid p-0 homeimg5">
    <div class="row">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 absoluteslide">
        
            
<div class="blog_text_slider">
                                <div class="blog_text">
                                    <div class="vr"><span class="homeimgbg5">Experience<br>Karmic</span></div>                                  
                                    <div class="blog-meta bottom d-flex justify-content-between align-items-center flex-wrap">
                                        <div class="meta">
                                            <span class="icon fa fa-calendar"></span> March 14, 2018
                                            <span class="icon fa fa-comments"></span> 05
                                        </div>
                                        <div>
                                            <a class="read_more" href="#">Read More</a>
                                        </div>
                                    </div>
                                    </div>
                                    </div>
        </div>
    </div>
</div>

</div>
<!---banner container-fluid-->
<div class="spacecontent">
</div>
<!---start of about us-->
<section class="about">
            <div class="container-fluid">
              <div class="row d-md-flex no-gutters slider-text align-items-center justify-content-end">
             
                <div class="col-lg-5 col-md-5 d-flex align-items-center ftco-animate fadeInUp ftco-animated">
                
                    <div class="text">
                        <h1 class="mb-4 mt-3">Know About Yogi360</h1>
                        <ul>
<li><span class="hcap">H</span>uman Begins are<i> <b>“Multi-dimensional Personalities”</b></i>.</li>
<li>Each one of us are a blend of <i>“Physical, Emotional, Psychological, Mystical and Spiritual Personalities”</i>. Rarely do we look beyond our Physical and Mental Capabilities. That is the cause of our suffering. </li>
<li>At Yogi 360, we are a group of Yoga Practioners willing and wanting to express the true nature and possibilities of Yoga. </li>
<li>Yogi 360 wants to share the wisdom of Yoga, which would help us to be self-sufficient and adopt Yoga as a way of life in every Profession, in every Relationship and in every Situations of our Life. </li>
<li>We want to elevate you beyond your suffering - be it <i>“Physical, Emotional or Psychological”.</i>  </li>
<li>Come, Let us Not Learn Yoga; <i><b>Let us Experience It!!!</b></i></li>

</ul>
                        <p><a href="#" class="btn btn-grey px-5 py-3 mt-3">Explore More <span class="ion-ios-arrow-forward"></span></a></p>
                    </div>
                </div>
                <div class="col-lg-1 col-md-1"></div>
                  <div class="col-lg-6 col-md-6 col-sm-12 regularanimate">
                        <div class="aboutcode aboutimg1">
                                <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg1">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg2">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg2">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg3">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg3">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg4">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg4">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg5">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg5">About Us</span></div>
                        </div>
                    
                    </div>
                </div><!---row -->
        </div>
    </section>
<!--end of about us -->


<div class="spacecontent">
</div>
<div class="ourcategory">
<div class="container-fluid">
    <div class="row alignitems"><h1>Our Category...</h1></div>

        <div class="row regularplus">

<div class="categorywidth">
<div class="single_place text-center categorywidth imgtilt" style="visibility: visible; animation-duration: 1s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat1.png')); ?>" style="width:261px!important; height:336px!imporctant;" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat2.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>

</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay=".4s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.4s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat3.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>

</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.6s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat4.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.6s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat5.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.6s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat6.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
</div>
</div>
</div>
<!---end of container-fluid -->

<div class="spacecontent">
</div>

<div class="container-fluid p-0">
    <div class="row no-gutters alignitems">
    <h1>Must Read...</h1>
    <!--<p>There is a moment in the life of any aspiring astronomer that it is time to buy that first telescope. It’s exciting to think about setting up your own viewing station.</p>-->
    </div>
<div class="row">
<div class="col-lg-3 col-md-6">
<div class="single_place text-center mt-480 imgtilt" data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust1.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="single_place text-center mt-240 imgtilt" data-wow-duration="1s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust2.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay="1s" style="visibility: visible; animation-duration: 1s; animation-delay: 1s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust3.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay=".4s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.4s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust4.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
<div class="single_place text-center imgtilt" data-wow-duration="1s" data-wow-delay=".8s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.8s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust5.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="single_place text-center mt-240 imgtilt" data-wow-duration="1s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.6s; animation-name: fadeIn;">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust6.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
</div>
</div>

<!---end of  -->
<div class="spacecontent">
</div>
<div class="row m-0">
            <div class="col-md-10 offset-md-1">
                <div class="row">
                    <div class="col-lg-12">
                        <h1>Latest Blogs...</h1>
                        <!--<p class="text-center">We inspire holidays for your body and mind. Find content that will wake
                            up the
                            traveller in you and get the best travel tips and tricks. We endeavour to create and share
                            the best,
                            amazing
                            and insightful blogs that will educate and inspire you to travel.</p>-->
                    </div>
                </div>
                <div class="row blog-main">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-12 col-xl-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height1">
                                            <img class="w-100" src="<?php echo e(asset('/public/images/blog.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Top 5 Ayurvedic resorts to explore across the globe</h6>
                                            <p>The practice of Ayurveda dated back from the year 3000, originated from South India and Sri Lanka. The oldest and the complete system of the world in medicine have made positive moves.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="w-100" src="<?php echo e(asset('/public/images/blog1.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Myths and Facts about Ayurveda Treatment </h6>
                                            <p>Embracing the natural yet holistic lifestyle are common factors in these days. The field of Ayurveda is often shrouded amid myths and misconceptions among the public.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="w-100" src="<?php echo e(asset('/public/images/blog2.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Natural Ways to Manage Diabetes through Ayurveda </h6>
                                            <p>Managing diabetes is one of the daily challenges that people with this condition need to deal with. </p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="-blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="w-100" src="<?php echo e(asset('/public/images/blog3.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Building bridges between Ayurveda and Modern Science</h6>
                                            <p>Ayurveda is based on ancient writings that rely on a “natural” and holistic approach to physical and mental health.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="w-100" src="<?php echo e(asset('/public/images/blog4.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Ayurveda-A journey from past to present into the future</h6>
                                            <p>One of the worlds’ oldest recorded systems of healthcare which is still practiced today is Ayurveda.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!--- end of blogs -->
<div class="spacecontent">
</div>
<section class="newsletter section_gap">
<div class="container">
<div class="row align-items-center justify-content-center">
<div class="col-lg-5">
<div class="main_title text-center">
<h1 class="text-center mb-5">Lets Stay in Touch</h1>
<h2 class="text-left">Subscribe to Newsletter!</h2>

<p class="text-left">Yogi360 is purely a growing community where we speak about anything and everthing under the sky, with a multidimensional approach and a multifaceted vision.</p>
<p class="text-left">Make this choice and from now on, you will forever be a part of every adventure!</p>
    <a class="text-uppercase ml-5">
SUBSCRIBE NOW
<img src="<?php echo e(asset('/public/images/rightarrow.png')); ?>" class="arrow ml-2" alt="">
</a>
</div>
</div>
<div class="col-lg-6 offset-lg-1">
<div id="f1_container">
<div class="text-center" id="f1_card" class="shadow">
  <div class="face">
    <img src="<?php echo e(asset('/public/images/new1.png')); ?>" style="width=455px; height:455px;"/>
    <div class="overlay"> </div>
    <button class="main_btn text-uppercase">
SUBSCRIBE NOW
<img src="img/next.png') }}" alt="">
</button>
  </div>
  <div class="back face">
<h1>Subscribe to our Newsletter!</h1>

<p>Make this choice and from now on, <br> you will forever be a part of every adventure!</p>
<div class="subscription" id="mc_embed_signup">
<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscription relative">
<input type="email" name="EMAIL" placeholder="Your email address" onfocus="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = ''" onblur="if (!window.__cfRLUnblockHandlers) return false; this.placeholder = 'Your email address'" required="">
<div style="position: absolute; left: -5000px;">
<input type="text" name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="">
</div>
<button class="btn-grad hover d-inline-flex align-items-center"><span class="mr-10">Get Started</span><span class="lnr lnr-arrow-right"></span></button>
<div class="info"></div>
</form>
</div>

  </div>
</div>
</div>
</div>
</div>
</section>
<div class="spacecontent">
</div>
<!---end of register now -->

<div class="heightspace">
</div>
<hr>
<footer class="footer-area">
<div class="container">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="#">Yogi360</a></li>
<li><a href="#">Yogi360 Live</a></li>
<li><a href="#">Yogi360 Ayurveda</a></li>
<li><a href="#">Yogi360 Retreat</a></li>
<li><a href="#">Yogi360 Jobs</a></li>
<li><a href="#">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="#">Yoga 101 </a></li>
<li><a href="#">Ayurveda</a></li>
<li><a href="#">Logical</a></li>
<li><a href="#">Viral</a></li>
<li><a href="#">Travel</a></li>
<li><a href="#">Awakening</a></li>
<li><a href="#">Yogis</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<p class="text-left">Mantra is not Religion<br>
Six steps of doing asana meditatively<br>
The purpose and utility of asanas in Hathayoga<br>
What is Ayurveda and how does it help Yoga<br>
What is real health in Yogic science for the Yogi<br>
Disciplines of yoga teachers and students</p>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="#">About Us</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row">

<p class="footer-text mx-auto">
Copyright © 2019 Yogi360, All rights reserved Powered By<a href="https://yogicconnection.com" target="_blank">Yogi360</a>
</p>
</div>
<div class="row mb-3">
<div class="footer-social d-flex mx-auto">
<a href="#"><i class="fa fa-facebook"></i></a>
<a href="#"><i class="fa fa-instagram"></i></a>
<a href="#"><i class="fa fa-linkedin"></i></a>
<a href="#"><i class="fa fa-twitter"></i></a>
<a href="#"><i class="fa fa-youtube"></i></a>
</div>
</div>
</div>

</footer>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  <script src="<?php echo e(asset('public/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
    <!--- sleek plugin -->
    
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <!-- Optional JavaScript -->
<script>
    $(function(){
    $(".dropdown").hover(            
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');              
            },
            function() {
                $('.dropdown-menu', this).stop( true, false ).fadeOut("fast");
                $(this).toggleClass('open');               
            });
    });
</script>
<script type="text/javascript">
      slick_slider = $('.regularplus');
    settings = {
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        arrow:false,
          infinite: true,
  cssEase: 'linear',
  variableWidth: true,
  variableHeight: true,
        pauseOnHover: true,
       
    };
    slick_slider.slick(settings);
    resetSlick(slick_slider, settings);
</script>
<script type="text/javascript">
    $(document).on('ready', function() {
  $(".regular").slick({
        dots: false,
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        fade:true,
        speed:500,
        autoplay:true,
              
      });
                $(".regularanimate").slick({
        dots: false,
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        fade:true,
        autoplay:true,

      });

        $(".regularbg").slick({
        dots: false,
        arrows: false,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay:true,

      });
});
</script>
</body>
</html>