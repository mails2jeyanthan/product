<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/css/style.css')); ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/slick/slick-theme.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700">
<link href="https://fonts.googleapis.com/css2?family=Varela+Round&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Muli&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
    
    <title>Blog | Yogi360</title>

  </head>
  <body>
<header class="header_area fixed-top">
<nav class="navbar navbar-expand-lg navbar-light bg-white pl-3 pr-3">
  <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/public/images/justice-logo.png')); ?>"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav ml-auto mt-2 mt-lg-0 text-uppercase">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">HOME<span class="sr-only">(current)</span></a>
      </li>
                       <li class="nav-item dropdown">
                      <a href="<?php echo e(url('/blogs-list')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown">category <b class="caret"></b></a>
                      <ul class="dropdown-menu text-center">
                        <li><a class="nav-link" href="<?php echo e(url('/yoga-101')); ?>">Yoga 101</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/practice')); ?>">Practice</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/travel')); ?>">Travel</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/logical')); ?>">Logical</a></li>
                        <li><a class="nav-link" href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
                      </ul>
                    </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/insurance')); ?>">INSURANCE</a>
      </li>
    </ul>
<form action="<?php echo e(url('/search')); ?>" method="POST" class="form-inline my-2 my-lg-0">
<?php echo e(csrf_field()); ?>

  <div class="search__wrapper">
    <input type="text" name="search" required="required" placeholder="Search for..." class="search__field">
    <button type="submit" class="fa fa-search search__icon"></button>
  </div>
</form>
  </div>
</nav>
</header>


<div class="regular onscrollfade">

<div class="container-fluid p-0 homeimg2">
    <div class="row">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 absoluteslide">
        
            
<div class="blog_text_slider">
                                <div class="blog_text">
                                    <div class="vr"><span class="homeimgbg2">Experience<br>Ayurvedic</span></div>                                   
                                    <div class="blog-meta bottom d-flex justify-content-between align-items-center flex-wrap">
                            
                                    </div>
                                    </div>
                                    </div>
        </div>
    </div>
</div>

<div class="container-fluid p-0 homeimg4">
    <div class="row">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 absoluteslide">
        
            
<div class="blog_text_slider">
                                <div class="blog_text bottom d-flex justify-content-between align-items-center flex-wrap">
                                    <div class="vr"><span class="homeimgbg4">Wisdom<br>Gain</span></div>                                    
                                    <div class="blog-meta bottom d-flex justify-content-between align-items-center flex-wrap">

                                    </div>
                                    </div>
                                    </div>
        </div>
    </div>
</div>
<div class="container-fluid p-0 homeimg5">
    <div class="row">

        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 absoluteslide">
        
            
<div class="blog_text_slider">
                                <div class="blog_text bottom d-flex justify-content-between align-items-center flex-wrap">
                                    <div class="vr"><span class="homeimgbg5">Bliss<br>Experience</span></div>
<div class="blog-meta bottom d-flex justify-content-between align-items-center flex-wrap">

                                    </div>                                  
                                    </div>
                                    </div>
        </div>
    </div>
</div>

</div>
<!---------------banner container-fluid----------------------->

<!------------start of about us------------------>
<section id="about" class="about">
            <div class="container-fluid">
              <div class="row d-md-flex no-gutters slider-text align-items-center justify-content-end">
             
                <div class="col-lg-5 col-md-12 d-flex align-items-center ftco-animate fadeInUp ftco-animated">
                
                    <div class="text">
                        <div class="web-tittle justify-content-center text-center mb-4 mt-3">Know About <span class="justify-content-center text-center">Yogi360</span></div>
                        <ul>
<li><span class="hcap">H</span>uman Begins are<i> <b>“Multi-dimensional Personalities”</b></i>.</li>
<li>Each one of us are a blend of <i>“Physical, Emotional, Psychological, Mystical and Spiritual Personalities”</i>. Rarely do we look beyond our Physical and Mental Capabilities. That is the cause of our suffering. </li>
<li>At Yogi 360, we are a group of Yoga Practioners willing and wanting to express the true nature and possibilities of Yoga. </li>
<li>Yogi 360 wants to share the wisdom of Yoga, which would help us to be self-sufficient and adopt Yoga as a way of life in every Profession, in every Relationship and in every Situations of our Life. </li>
<li>We want to elevate you beyond your suffering - be it <i>“Physical, Emotional or Psychological”.</i>  </li>
<li>Come, Let us Not Learn Yoga; <i><b>Let us Experience It!!!</b></i></li>

</ul>
                        <p><a href="#" class="btn btn-grey px-5 py-3 mt-3">Explore More <span class="ion-ios-arrow-forward"></span></a></p>
                    </div>
                </div>
                <div class="col-lg-1"></div>
                  <div class="col-lg-6 col-md-12 col-sm-12 regularanimate">
                        <div class="aboutcode aboutimg1">
                                <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg1">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg2">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg2">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg3">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg3">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg4">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg4">About Us</span></div>
                        </div>
                        <div class="aboutcode aboutimg5">
                            <div class="overlay"> </div>
                                <div class="vr"><span class="aboutbg5">About Us</span></div>
                        </div>
                    
                    </div>
                </div><!-------------row ------------------------>
        </div>
    </section>
<!----------end of about us ---------->


<div class="spacecontent">
</div>
<div class="ourcategory">
<div class="container-fluid">
    <div class="row alignitems mobcenter"><div class="web-tittle text-center">Our <br><span>Category...</span></div></div>

        <div class="row regularplus">

<div class="categorywidth">
<div class="single_place text-center categorywidth imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat1.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat2.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>

</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat3.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>

</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat4.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat5.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
<div class="categorywidth">
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/cat6.png')); ?>" alt="">
<div class="overlay"></div>
<h4>Waterfall
<br> Mountain Island</h4>
</div>
</div>
</div>
</div>
</div>
<!-----------------end of container-fluid -------------------------->

<div class="spacecontent">
</div>

<div class="container-fluid p-0">
    <div class="row alignitems mobcenter"><div class="web-tittle text-center">
    Must<br><span> Read...</span></div>
    <!--<p>There is a moment in the life of any aspiring astronomer that it is time to buy that first telescope. It’s exciting to think about setting up your own viewing station.</p>-->
    </div>
<div class="row">
<div class="col-lg-3 col-md-6">
<div class="single_place text-center mt-480 imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust1.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="single_place text-center mt-240 imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust2.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust3.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust4.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
<div class="single_place text-center imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust5.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
<div class="col-lg-3 col-md-6">
<div class="single_place text-center mt-240 imgtilt">
<img class="img-fluid w-100" src="<?php echo e(asset('/public/images/rmust6.png')); ?>" alt="">
<div class="overlay"></div>
<!-- <h4>Waterfall -->
<!-- <br> Mountain Island</h4> -->
</div>
</div>
</div>
</div>

<!-----------------end of  -------------------------->
<div class="spacecontent">
</div>
<div class="row m-0">
            <div class="col-md-10 offset-md-1">
                <div class="row mobcenter">
                    <div class="col-lg-12">
                    <div class="web-tittle">
    Latest<br><span> Blogs...</span></div>
                                            
                    </div>
                </div>
                <div class="row blog-main">
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-12 col-xl-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height1">
                                            <img class="img-fluid d-block" src="<?php echo e(asset('/public/images/blog.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Top 5 Ayurvedic resorts to explore across the globe</h6>
                                            <p>The practice of Ayurveda dated back from the year 3000, originated from South India and Sri Lanka. The oldest and the complete system of the world in medicine have made positive moves.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="img-fluid d-block" src="<?php echo e(asset('/public/images/blog1.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Myths and Facts about Ayurveda Treatment </h6>
                                            <p>Embracing the natural yet holistic lifestyle are common factors in these days. The field of Ayurveda is often shrouded amid myths and misconceptions among the public.</p>
                                        </div>
                                    </a>
                                </div>
                         



                         </div>
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="img-fluid d-block" src="<?php echo e(asset('/public/images/blog2.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Natural Ways to Manage Diabetes through Ayurveda </h6>
                                            <p>Managing diabetes is one of the daily challenges that people with this condition need to deal with. </p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="-blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="img-fluid d-block" src="<?php echo e(asset('/public/images/blog3.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Building bridges between Ayurveda and Modern Science</h6>
                                            <p>Ayurveda is based on ancient writings that rely on a “natural” and holistic approach to physical and mental health.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-12 col-xl-6 col-lg-6 col-md-12 p-0">
                                <div class="blogContent">
                                    <a href="#" target="_blank">
                                        <div class="img-zoom-in img-height2">
                                            <img class="img-fluid d-block" src="<?php echo e(asset('/public/images/blog4.png')); ?>">
                                        </div>
                                        <div class="blogPara">
                                            <h6>Ayurveda-A journey from past to present into the future</h6>
                                            <p>One of the worlds’ oldest recorded systems of healthcare which is still practiced today is Ayurveda.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!----------------------------- end of blogs ------------------------------------>
<div class="spacecontent">
</div>
<section class="newsletter section_gap onscrollfade">
<div class="container">
<div class="row align-items-center justify-content-center">
<div class="col-lg-5 col-md-12">
<div class="main_title text-center">
<div class="web-tittle text-center mb-5">
    Lets Stay<br><span> in Touch...</span></div>
<h2 class="text-left">Subscribe to Newsletter!</h2>

<p class="text-left">Yogi360 is purely a growing community where we speak about anything and everthing under the sky, with a multidimensional approach and a multifaceted vision.</p>
<p class="text-left">Make this choice and from now on, you will forever be a part of every adventure!</p>
    <a class="text-uppercase ml-5">
SUBSCRIBE NOW
<img src="<?php echo e(asset('/public/images/rightarrow.png')); ?>" class="arrow ml-2" alt="">
</a>
</div>
</div>
<div class="col-lg-6 offset-lg-1">
<div class="containerflip">
    <div class="front side">
        <div class="content pt-5">
            <h1>Join US</h1>
            <p>
Register here for more update
            </p>
        </div>
                    <div class="spacecontent">
</div>
<div class="spacecontent">
</div>
<div class="spacecontent">
</div>
                <div class="align-center"><a href="https://www.yogi360blogs.com/" target="_blank" class="box-shadow subscribe-button">Subscribe Now</a></div>
                
            
    </div>
    <div class="back side">
        <div class="content pt-5">
            <h1>Subscribe to our Newsletter</h1>
            <form>
                <div class="spacecontent">
</div>
<div class="spacecontent">
</div>

                <label>Your E-mail :</label>
                <input type="email" placeholder="email@address.com" id="email" name="email">

                <input class="mt-3" type="submit" value="Get Started">
            </form>
        </div>
    </div>

</div>
</div>
</div>
</section>
<div class="spacecontent">
</div>
<!------------------end of register now ------------------------------------------------------------>

<div class="heightspace">
</div>

<div class="heightspace">
</div>
<footer class="footer-area">
<div class="container onscrollfade">

<div class="row footer-top">
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>OUR SERVICES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="https://www.yogi360.com/">Yogi360</a></li>
<li><a href="https://www.yogi360live.com/">Yogi360 Live</a></li>
<li><a href="https://www.yogi360ayurveda.com/">Yogi360 Ayurveda</a></li>
<li><a href="https://www.yogi360retreats.com/">Yogi360 Retreat</a></li>
<li><a href="https://www.yogi360jobs.com">Yogi360 Jobs</a></li>
<li><a href="https://www.yogi360store.com">Yogi360 Stores</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-3 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>TOP CATEGORIES</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/yoga-101')); ?>">Yoga 101 </a></li>
<li><a href="<?php echo e(url('/ayurveda')); ?>">Ayurveda</a></li>
<li><a href="<?php echo e(url('/logical')); ?>">Logical</a></li>
<li><a href="<?php echo e(url('/blogs-list')); ?>">Viral</a></li>
<li><a href="<?php echo e(url('/travel')); ?>">Travel</a></li>
<li><a href="<?php echo e(url('/inspiring')); ?>">Inspiring</a></li>
<li><a href="<?php echo e(url('/lifestyle')); ?>">Lifestyle</a></li>
</ul>
</div>
</div>
</div>
<div class="col-lg-4  col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>POPULAR BLOGS</h6>
<div class="row">
<p class="text-left">
<a href="<?php echo e(url('/blog-details-1/1')); ?>">Emotion | Body | Yoga : A connection that you need to know</a><br>
<a href="<?php echo e(url('/blog-details-3/1')); ?>">Teach your students by Wisdom and not by Hand</a><br>
<a href="<?php echo e(url('/blog-details-4/1')); ?>">Physical Training or Yoga- Which is more important in school?</a><br>
<a href="<?php echo e(url('/blog-details-5/1')); ?>">How does a mantra purify emotional lifestyles?</a><br>
<a href="<?php echo e(url('/blog-details-6/1')); ?>">Breathing purifies your emotions: Did you know it?</a><br>
<a href="<?php echo e(url('/blog-details-7/2')); ?>">Yoga practitioners diet: Are you eating what your body demands?</a>
</p>
</div>
</div>
</div>

<div class="col-lg-2 col-md-6 col-sm-6">
<div class="single-footer-widget">
<h6>YOGI 360 BLOGS</h6>
<div class="row">
<ul class="col footer-nav">
<li><a href="<?php echo e(url('/#about')); ?>">About Us</a></li>
<li><a href="<?php echo e(url('/contact-us')); ?>">Contact Us</a></li>
<li><a href="<?php echo e(url('/privacy-policy')); ?>">Privacy Policy</a></li>
<li><a href="<?php echo e(url('/terms-and-conditions')); ?>">Terms & Condition</a></li>
</ul>
</div>
</div>
</div>
</div>
</div>

<div class="container-fluid p-0 text-center">
<div class="row justify-content-center pb-3">


Copyright © 2019 Yogi360, <br>All rights reserved Powered By Yogi360

</div>
<div class="row pb-3">
<div class="footer-social d-flex mx-auto">
<a href="#"><img src="<?php echo e(asset('/public/images/face.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/insta.png')); ?>"></a>
<a href="#"><img src="<?php echo e(asset('/public/images/link.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/tweet.png')); ?>"></i></a>
<a href="#"><img src="<?php echo e(asset('/public/images/you.png')); ?>"></i></a>
</div>
</div>
</div>

</footer>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
  <script src="<?php echo e(asset('/public/slick/slick.js')); ?>" type="text/javascript" charset="utf-8"></script>
    <!--- sleek plugin ------------>
    
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <!-- Optional JavaScript -->
        
        <script src="<?php echo e(asset('/public/js/slider.js')); ?>" type="text/javascript" charset="utf-8"></script>
        <script>
            slick_slider.slick(settings);
    resetSlick(slick_slider, settings);
        $(function(){
    $(".dropdown").hover(            
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');              
            },
            function() {
                $('.dropdown-menu', this).stop( true, false ).fadeOut("fast");
                $(this).toggleClass('open');               
            });
    });
        </script>
        
    
  </body>
</html>